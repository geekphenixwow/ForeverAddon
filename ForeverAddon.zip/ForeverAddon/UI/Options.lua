local _,app=...
local atlas="Interface\\AddOns\\ForeverAddon\\Media\\Azeroth.tga"
local gold={0.78,0.57,0.19}
local function copy(value)
    if type(value)~="table" then return value end
    local result={}; for key,item in pairs(value) do result[key]=copy(item) end; return result
end
local function text(parent,value,x,y,width,style)
    local t=parent:CreateFontString(nil,"OVERLAY",style or "GameFontHighlight")
    t:SetPoint("TOPLEFT",x,y); t:SetWidth(width or 940); t:SetJustifyH("LEFT"); t:SetText(value)
    return t
end
local function art(parent,sx,sy,sw,sh,x,y,w,h)
    -- Artwork must stay above BackdropTemplate's regenerated background.
    local t=parent:CreateTexture(nil,"ARTWORK",nil,0)
    t:SetTexture(atlas); t:SetTexCoord(sx/1024,(sx+sw)/1024,sy/1024,(sy+sh)/1024)
    t:SetPoint("TOPLEFT",x,y); t:SetSize(w,h); return t
end
local function box(parent,x,y,w,h,title)
    local f=CreateFrame("Frame",nil,parent,"BackdropTemplate")
    f:SetPoint("TOPLEFT",x,y); f:SetSize(w,h)
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    f:SetBackdropColor(0.035,0.045,0.055,0.98); f:SetBackdropBorderColor(gold[1],gold[2],gold[3],0.8)
    art(f,8,238,584,33,0,0,w,33)
    local heading=text(f,title,40,0,w-80,"GameFontNormal")
    heading:SetHeight(33); heading:SetJustifyH("CENTER"); heading:SetJustifyV("MIDDLE")
    return f
end
local function button(parent,title,x,y,w,action)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",x,y); b:SetSize(w,32); b:SetText(title); b:SetScript("OnClick",action)
    return b
end
local function check(window,parent,title,x,y,get,set)
    local b=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    b:SetPoint("TOPLEFT",x,y); b:SetSize(28,28)
    local caption=b:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    caption:SetPoint("LEFT",b,"RIGHT",6,0); caption:SetText(title)
    b:SetScript("OnClick",function() set(b:GetChecked() and true or false); app:RefreshOptions() end)
    window.checks[#window.checks+1]={frame=b,get=get}; b:SetChecked(get())
    return b
end
function app:StatusText()
    local b,reason=self:Bridge()
    if not b then return reason.."\nÉtends WoW dans le compagnon, puis clique sur Recharger l’interface." end
    local state=not self.db.enabled and "Affichage double écran désactivé" or (self.viewportActive and "Monde 3D sur l’écran du jeu · espace secondaire séparé" or "Cadrage à appliquer")
    return state.."\nJeu : "..b.game.w.." × "..b.game.h.."  |  Écran secondaire : "..b.workspace.w.." × "..b.workspace.h
end
function app:RefreshOptions()
    local f=self.options; if not f then return end
    f.status:SetText(self:StatusText())
    for _,item in ipairs(f.checks) do item.frame:SetChecked(item.get()) end
    for key,label in pairs(f.scaleTexts) do label:SetText(math.floor((self.db.scales[key] or 1)*100+0.5).." %") end
    if f.refreshProfiles then f.refreshProfiles() end
end
function app:ResetPanel(key)
    for name in pairs(self.db.positions) do
        if name==key or key=="ContainerFrameCombinedBags" and (name:match("^ContainerFrame%d+$") or name:match("^BagSlot%d+$")) then self.db.positions[name]=nil end
    end
    self.db.scales[key]=nil; self:Apply(); self:RefreshOptions()
end
function app:LayoutOptions()
    if self.LayoutHUDAssistant then self:LayoutHUDAssistant() end
    local f=self.options; if not f then return end
    local x,y,w,h=self:Area("game")
    if not self.db.enabled then x,y,w,h=nil,nil,nil,nil end
    local availableW,availableH=w or UIParent:GetWidth(),h or UIParent:GetHeight()
    f:SetScale(math.max(0.2,math.min(1,(availableW-32)/1080,(availableH-32)/850)))
    f:ClearAllPoints()
    if x then
        local ratio=UIParent:GetEffectiveScale()/f:GetEffectiveScale()
        f:SetPoint("CENTER",UIParent,"TOPLEFT",(x+w/2)*ratio,(y-h/2)*ratio)
    else f:SetPoint("CENTER",UIParent,"CENTER",0,0) end
end
function app:ShowOptions(index)
    if self.options then self:LayoutOptions(); self.options:Show(); if index then self.options.select(index) end; self:RefreshOptions(); return end
    local f=CreateFrame("Frame","FDSLocalOptions",UIParent,"BackdropTemplate")
    self.options=f; f.checks={}; f.scaleTexts={}
    f:SetSize(1080,850); f:SetFrameStrata("DIALOG"); f:SetClampedToScreen(true)
    self:LayoutOptions()
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart",f.StartMoving); f:SetScript("OnDragStop",f.StopMovingOrSizing)
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=24,insets={left=6,right=6,top=6,bottom=6}})
    f:SetBackdropColor(0.02,0.028,0.038,1); f:SetBackdropBorderColor(gold[1],gold[2],gold[3],1)
    -- Continuous horizontal slices retain the complete original header.
    -- Only the two connecting wings expand; the globe and banners keep their shape.
    f.headerArt={
        art(f,0,0,140,235,18,-8,140,235),
        art(f,140,0,40,235,158,-8,262,235),
        art(f,180,0,240,235,420,-8,240,235),
        art(f,420,0,40,235,660,-8,262,235),
        art(f,460,0,140,235,922,-8,140,235),
    }
    local nexus=f:CreateTexture(nil,"OVERLAY")
    nexus:SetTexture("Interface\\AddOns\\ForeverAddon\\Media\\Nexus.tga");nexus:SetSize(176,176);nexus:SetPoint("TOP",f,"TOP",0,-7)
    local title=text(f,"Forever Addon",225,-160,630,"GameFontNormalLarge")
    title:SetJustifyH("CENTER"); title:SetFont("Fonts\\FRIZQT__.TTF",27,"OUTLINE")
    local versions=text(f,"Addon "..app.version.."  ·  Compagnon 0.4.1",225,-194,630,"GameFontHighlightSmall"); versions:SetJustifyH("CENTER")
    local subtitle=text(f,"Ton interface, tes écrans, tes modules.",225,-216,630); subtitle:SetJustifyH("CENTER")
    local close=CreateFrame("Button",nil,f,"UIPanelCloseButton"); close:SetPoint("TOPRIGHT",-9,-9)
    table.insert(UISpecialFrames,"FDSLocalOptions")
    local titles={"Affichage et zone de jeu","Écran secondaire et carte","Profils","Modules complémentaires"}
    f.pages={}; f.tabs={}
    function f.select(selected)
        for n,page in ipairs(f.pages) do
            page:SetShown(n==selected)
            local tab=f.tabs[n]
            tab:SetBackdropColor(n==selected and 0.065 or 0.025,n==selected and 0.15 or 0.055,n==selected and 0.20 or 0.075,1)
            tab:SetBackdropBorderColor(n==selected and 0.18 or gold[1],n==selected and 0.80 or gold[2],n==selected and 1 or gold[3],1)
        end
        f.currentPage=selected; app:RefreshOptions()
    end
    for i,title in ipairs(titles) do
        local page=CreateFrame("Frame",nil,f); page:SetPoint("TOPLEFT",20,-360); page:SetSize(1040,410); f.pages[i]=page
        local tab=CreateFrame("Button",nil,f,"BackdropTemplate")
        tab:SetPoint("TOPLEFT",i==4 and 720 or 20+(i-1)*350,i==4 and -306 or -254); tab:SetSize(340,44)
        tab:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        tab:SetNormalFontObject("GameFontNormal"); tab:SetText(title)
        local selected=i; tab:SetScript("OnClick",function() f.select(selected) end); f.tabs[i]=tab
    end
    f.status=text(f,self:StatusText(),28,-312,675,"GameFontHighlightSmall");f.status:SetHeight(40)
    local p=box(f.pages[1],0,0,1040,185,"Moniteurs et vue du jeu")
    check(f,p,"Activer le double écran",20,-44,function() return app.db.enabled end,function(v) app:SetEnabled(v) end)
    check(f,p,"Adapter le HUD à l'écran du jeu",20,-86,function() return app.db.hud end,function(v) app:SetHUDEnabled(v) end)
    check(f,p,"Afficher l’icône de minicarte",20,-128,function() return not app.db.minimapHidden end,function(v) app.db.minimapHidden=not v; if app.minimapButton then app.minimapButton:SetShown(v) end end)
    text(p,"Choisis les écrans dans le compagnon.\nL'assistance crée une copie de ton HUD d'origine\nsans modifier la disposition source.",560,-47,440)
    button(p,"Assistance de placement du HUD",560,-127,440,function() app:ShowHUDAssistant() end)
    p=box(f.pages[1],0,-205,1040,175,"Application et récupération")
    button(p,"Recharger l’interface",20,-44,310,function()
        if InCombatLockdown() then app:Message("Attends la fin du combat pour recharger."); return end
        app.db.manualBridge=nil; app.db.enabled=true; app.db.userDisabled=false; ReloadUI()
    end)
    button(p,"Diagnostic du cadrage",365,-44,310,function() app:ViewportDiagnostic() end)
    button(p,"Désactiver et restaurer",710,-44,310,function() app:SetEnabled(false); app:RefreshOptions() end)
    text(p,"Après Étendre WoW, recharge ici pour lire\nle placement transmis par le compagnon.",20,-88,320,"GameFontHighlightSmall")
    text(p,"Affiche les mesures du jeu et des écrans\npour comprendre un problème de placement.",365,-88,320,"GameFontHighlightSmall")
    text(p,"Désactive la séparation dans l'addon.\nLa fenêtre Windows se restaure dans le compagnon.",710,-88,310,"GameFontHighlightSmall")
    p=box(f.pages[2],0,0,1040,250,"Fenêtres déplaçables sur les deux écrans")
    text(p,"Déplacement libre sur les deux écrans. Position mémorisée au relâchement.",20,-38,655,"GameFontHighlightSmall")
    local selectAll=button(p,"Tout cocher",710,-34,135,function() app:SetAllPanels(true) end)
    local selectNone=button(p,"Tout décocher",855,-34,155,function() app:SetAllPanels(false) end)
    selectAll:SetHeight(26); selectNone:SetHeight(26)
    local scroll=CreateFrame("ScrollFrame",nil,p,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",12,-72); scroll:SetSize(988,166)
    local content=CreateFrame("Frame",nil,scroll)
    content:SetPoint("TOPLEFT",scroll,"TOPLEFT",0,0)
    content:SetSize(980,#app.panelCatalog*43+4); scroll:SetScrollChild(content)
    f.panelScroll=scroll
    for i,item in ipairs(app.panelCatalog) do
        local key=item[2]; local row=-(i-1)*43
        check(f,content,item[1],8,row,function() return app.db.panels[key] end,function(v) app.db.panels[key]=v; app:Apply() end)
        button(content,"-",490,row,42,function() app.db.scales[key]=math.max(0.25,(app.db.scales[key] or 1)-0.05); app:Apply(); app:RefreshOptions() end)
        f.scaleTexts[key]=text(content,"100 %",545,row-9,80)
        button(content,"+",630,row,42,function() app.db.scales[key]=math.min(2,(app.db.scales[key] or 1)+0.05); app:Apply(); app:RefreshOptions() end)
        if key=="WorldMapFrame" then button(content,"Ouvrir la carte",710,row,260,function() app:ShowWorkspaceMap() end)
        else button(content,"Réinitialiser",710,row,260,function() app:ResetPanel(key) end) end
    end
    p=box(f.pages[2],0,-270,1040,135,"Placement et fond de l'écran secondaire")
    check(f,p,"Adapter les fenêtres à la place disponible",20,-40,function() return app.db.autoFit end,function(v) app.db.autoFit=v; app:Apply() end)
    button(p,"Fond : pierre sombre",555,-38,220,function() app.db.background="stone"; app:Apply() end)
    button(p,"Fond : noir",790,-38,220,function() app.db.background="black"; app:Apply() end)
    button(p,"Réinitialiser les positions",20,-88,310,function() app.db.positions={}; app:Apply() end)
    button(p,"Rassembler sur l'écran du jeu",365,-88,310,function() app:Recover() end)
    button(p,"Restaurer les tailles",710,-88,310,function() app.db.scales={}; app:Apply(); app:RefreshOptions() end)
    p=box(f.pages[4],0,0,1040,365,"Gestion des sacs — options facultatives")
    check(f,p,"Afficher la poubelle sur le sac combiné",20,-48,function() return app.db.modules.bagTrash end,function(v) app:SetBagToolOption("bagTrash",v) end)
    text(p,"Dépose une pile sur la poubelle : la demande de destruction est immédiate.\nLes confirmations de Blizzard restent actives.",56,-88,950)
    check(f,p,"Activer la sélection multiple",20,-143,function() return app.db.modules.bagMulti end,function(v) app:SetBagToolOption("bagMulti",v) end)
    text(p,"Clique Sélection, puis coche les piles dans le sac : elles sont encadrées en rouge.\nLe bouton devient une poubelle. Reclique pour lancer la première pile, puis suis la progression.",56,-183,950)
    text(p,"Une pile par clic de validation. Aucun effacement automatique en série.\nLe mode de sélection est suspendu en combat et annulé si les objets sélectionnés changent.",20,-255,990,"GameFontHighlightSmall")
    button(p,"Ouvrir les sacs Blizzard",20,-313,310,function()
        if InCombatLockdown() then app:Message("Attends la fin du combat.");return end
        if OpenBackpack then OpenBackpack() end
    end)
    p=box(f.pages[3],0,0,1040,405,"Vos profils")
    text(p,"Nom du profil",20,-40,400,"GameFontNormal")
    local edit=CreateFrame("EditBox",nil,p,"InputBoxTemplate")
    edit:SetPoint("TOPLEFT",26,-67); edit:SetSize(420,30); edit:SetAutoFocus(false); edit:SetMaxLetters(40); edit:SetText(app.db.activeProfile or "Mon profil")
    local function name() return edit:GetText():match("^%s*(.-)%s*$") end
    local notice=text(p,"",20,-116,1000)
    local profileKeys={"panels","positions","scales","autoFit","hud","minimapHidden","background","modules"}
    local function save()
        local key=name(); if key=="" then notice:SetText("Indique un nom de profil."); return end
        local data={}; for _,field in ipairs(profileKeys) do data[field]=copy(app.db[field]) end
        app.db.profiles[key]=data; app.db.activeProfile=key; notice:SetText("Profil enregistré : "..key); app:RefreshOptions()
    end
    local function load()
        local key=name(); local saved=app.db.profiles[key]
        if not saved then notice:SetText("Ce profil n’existe pas encore."); return end
        for _,field in ipairs(profileKeys) do if saved[field]~=nil then app.db[field]=copy(saved[field]) end end
        app.db.activeProfile=key
        if app.minimapButton then app.minimapButton:SetShown(not app.db.minimapHidden) end
        app:Apply(); notice:SetText("Profil chargé : "..key); app:RefreshOptions()
    end
    button(p,"Enregistrer",480,-64,250,save)
    button(p,"Charger",750,-64,250,load)
    button(p,"Supprimer ce profil",750,-106,250,function() app.db.profiles[name()]=nil; notice:SetText("Profil supprimé."); app:RefreshOptions() end)
    text(p,"Un profil conserve les fenêtres choisies, leurs\npositions, leurs tailles et le recentrage du HUD.\n\nLes moniteurs physiques se choisissent\ntoujours dans le compagnon.",515,-183,480)
    local list={}; local offset=0; local keys={}
    for i=1,5 do
        local row=i
        list[i]=button(p,"",20,-164-(i-1)*39,450,function() local key=keys[offset+row]; if key then edit:SetText(key); load() end end)
    end
    button(p,"Précédents",20,-365,215,function() offset=math.max(0,offset-5); f.refreshProfiles() end)
    button(p,"Suivants",255,-365,215,function() if offset+5<#keys then offset=offset+5 end; f.refreshProfiles() end)
    function f.refreshProfiles()
        keys={}; for key in pairs(app.db.profiles) do keys[#keys+1]=key end; table.sort(keys)
        if offset>=#keys then offset=0 end
        for i,b in ipairs(list) do local key=keys[offset+i]; b:SetShown(key~=nil); if key then b:SetText(key) end end
    end
    button(f,"Réappliquer la disposition",20,-800,310,function() app:Apply(); app:RefreshOptions() end)
    text(f,"Les réglages sont sauvegardés automatiquement.",365,-810,360,"GameFontHighlightSmall")
    button(f,"Fermer",750,-800,310,function() f:Hide() end)
    f:SetScript("OnShow",function() app:RefreshOptions() end)
    f.select(index or 1)
end
