local _, app = ...
app.Geometry = {}
local G = app.Geometry
local function number(v) return type(v) == "number" and v == v and v > -100000 and v < 100000 end
function G.ValidRect(r)
    return type(r) == "table" and number(r.x) and number(r.y) and number(r.w) and number(r.h) and r.w > 0 and r.h > 0
end
function G.Contains(outer, inner)
    return G.ValidRect(outer) and G.ValidRect(inner) and inner.x >= outer.x and inner.y >= outer.y
        and inner.x + inner.w <= outer.x + outer.w and inner.y + inner.h <= outer.y + outer.h
end
function G.Validate(b)
    if type(b) ~= "table" or b.protocol ~= 1 or b.active ~= true then return false, "Aucun placement actif du nouveau compagnon." end
    if not G.Contains(b.canvas, b.game) or not G.Contains(b.canvas, b.workspace) then return false, "Disposition des écrans invalide." end
    local a, c = b.game, b.workspace
    if a.x < c.x+c.w and c.x < a.x+a.w and a.y < c.y+c.h and c.y < a.y+a.h then
        return false, "Les deux zones se chevauchent."
    end
    return true
end
function G.ToUI(r, canvas, width, height)
    return (r.x-canvas.x)/canvas.w*width, -(r.y-canvas.y)/canvas.h*height,
        r.w/canvas.w*width, r.h/canvas.h*height
end
function G.Matches(canvas, width, height)
    return G.ValidRect(canvas) and math.abs(canvas.w-width) <= 4 and math.abs(canvas.h-height) <= 4
end
function G.SurfaceState(b,reportedW,reportedH,uiW,uiH)
    local valid,reason=G.Validate(b)
    if not valid then return false,reason end
    if not number(uiW) or not number(uiH) or uiW<=0 or uiH<=0 then return false,"Dimensions de l’interface indisponibles." end
    local expected=b.canvas.w/b.canvas.h
    local visible=uiW/uiH
    if math.abs(visible/expected-1)>0.003 then
        return false,"L’interface n’a pas encore la forme des deux écrans. Étends WoW, puis recharge l’interface."
    end
    if not number(reportedW) or not number(reportedH) or reportedW<=0 or reportedH<=0 then return false,"Mesure native indisponible." end
    if G.Matches(b.canvas,reportedW,reportedH) then return true,"CANVAS" end
    local monitorSized=math.abs(reportedW-b.game.w)<=4 and math.abs(reportedH-b.game.h)<=4
        or math.abs(reportedW-b.workspace.w)<=4 and math.abs(reportedH-b.workspace.h)<=4
    if monitorSized and math.abs((reportedW/reportedH)/expected-1)>0.003 then return true,"MONITOR_REPORT" end
    return false,"La mesure native et l’interface ne permettent pas de confirmer le placement. Recharge l’interface."
end
function G.Calibrate(cw,ch,gw,gh,sw,sh,side,alignEnd)
    if not number(cw) or not number(ch) or not number(gw) or not number(gh) or not number(sw) or not number(sh) then
        return nil,"Les dimensions doivent être des nombres positifs."
    end
    for _,v in ipairs({cw,ch,gw,gh,sw,sh}) do
        if not number(v) or v<=0 then return nil,"Les dimensions doivent être des nombres positifs." end
    end
    local game={x=0,y=0,w=gw,h=gh}; local work={x=0,y=0,w=sw,h=sh}
    local width,height
    if side=="left" or side=="right" then
        width,height=gw+sw,math.max(gh,sh)
        if side=="left" then work.x=gw else game.x=sw end
        if alignEnd then game.y=height-gh; work.y=height-sh end
    elseif side=="top" or side=="bottom" then
        width,height=math.max(gw,sw),gh+sh
        if side=="top" then work.y=gh else game.y=sh end
        if alignEnd then game.x=width-gw; work.x=width-sw end
    else return nil,"Choisis la position de l’écran du jeu." end
    if width~=cw or height~=ch then
        return nil,"Ces dimensions ne correspondent pas à la fenêtre WoW étendue ("..cw.." × "..ch..")."
    end
    return {protocol=1,active=true,companion="calibrage en jeu",canvas={x=0,y=0,w=cw,h=ch},game=game,workspace=work}
end
function G.CalibrationDraft(gw,gh,sw,sh,side,alignEnd)
    if not number(gw) or not number(gh) or not number(sw) or not number(sh) or math.min(gw,gh,sw,sh)<=0 then
        return nil,"Indique les quatre résolutions des écrans."
    end
    local horizontal=side=="left" or side=="right"
    local cw=horizontal and gw+sw or math.max(gw,sw)
    local ch=horizontal and math.max(gh,sh) or gh+sh
    return G.Calibrate(cw,ch,gw,gh,sw,sh,side,alignEnd)
end
