local _,app=...
-- Local optical handshake for the companion. Eight solid UI pixels groups;
-- no screen capture is stored or transmitted, and no game memory is read.
-- A tiny strip in the workspace bottom-right is sampled by the companion.
-- Before spanning, it uses the same corner of the ordinary client.
-- A root frame survives UIParent visibility changes (Alt+Z/cinematics).
local colors={{1,0,1},{0,1,1},{1,1,0},{0,0,1},{0,1,0},{1,0,0},{0,1,1},{1,0,1}}
function app:LayoutSessionMarker()
    local f=self.sessionMarker
    if not f then return end
    f:SetScale(UIParent:GetEffectiveScale())
    local x,y,w,h=app:Area("workspace")
    if not x then x,y,w,h=0,0,UIParent:GetWidth(),UIParent:GetHeight() end
    for i,t in ipairs(f.blocks) do
        t:ClearAllPoints()
        t:SetPoint("TOPLEFT",UIParent,"TOPLEFT",x+w*(0.975+(i-1)*0.002),y-h*0.994)
        t:SetSize(w*0.0016,h*0.003)
    end
end
local events=CreateFrame("Frame")
for _,event in ipairs({"PLAYER_LOGIN","PLAYER_LOGOUT","DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do events:RegisterEvent(event) end
events:SetScript("OnEvent",function(_,event)
    if event=="PLAYER_LOGOUT" then if app.sessionMarker then app.sessionMarker:Hide() end; return end
    if event=="PLAYER_LOGIN" and not app.sessionMarker then
        local f=CreateFrame("Frame",nil,nil)
        f:SetFrameStrata("TOOLTIP"); f:SetFrameLevel(10000); f:EnableMouse(false)
        f:SetSize(1,1); f:SetPoint("TOPLEFT",UIParent,"TOPLEFT",0,0)
        f.blocks={}; app.sessionMarker=f
        for _,c in ipairs(colors) do
            local t=f:CreateTexture(nil,"OVERLAY"); t:SetColorTexture(c[1],c[2],c[3],1); f.blocks[#f.blocks+1]=t
        end
    end
    if app.sessionMarker then app:LayoutSessionMarker(); app.sessionMarker:Show() end
end)
