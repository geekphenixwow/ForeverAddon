local _,app=...
local pivots={TOPLEFT={0,0},TOP={0.5,0},TOPRIGHT={1,0},LEFT={0,0.5},CENTER={0.5,0.5},RIGHT={1,0.5},BOTTOMLEFT={0,1},BOTTOM={0.5,1},BOTTOMRIGHT={1,1}}
local function copy(v) if type(v)~="table" then return v end; local r={}; for k,x in pairs(v) do r[k]=copy(x) end; return r end
local function manager() local m=EditModeManagerFrame; return m and m.layoutInfo and m end
local function key(system) return tostring(system.system)..":"..tostring(system.systemIndex) end
local function name(frame) return type(frame)=="string" and frame or frame and frame.GetName and frame:GetName() end
local function ready()
    if InCombatLockdown() then return "Attends la fin du combat." end
    local m=manager()
    if not m then return "Le mode Édition n'est pas encore disponible." end
    if m:IsShown() or m.HasActiveChanges and m:HasActiveChanges() then return "Enregistre puis ferme le mode Édition avant de restaurer le HUD." end
end
local function signature()
    local b=app:Bridge(); if not b then return nil end
    local x,y,w,h=app:Area("game")
    return table.concat({x,y,w,h,UIParent:GetWidth(),UIParent:GetHeight()},":")
end
function app:IsBlizzardHUDActive()
    if not self.db.enabled or not self.db.hud or not self.viewportActive or self.blizzardHUDJob then return false end
    local m=manager(); if not m then return false end
    local s=self:GetHUDState(); local active=m.layoutInfo.layouts[m.layoutInfo.activeLayout]
    return s.mode=="blizzard" and active and active.layoutName==s.generatedName
end
local function registeredParent(relative,registered)
    local frame=type(relative)=="string" and _G[relative] or relative
    for i=1,12 do
        if not frame or frame==UIParent then return false end
        if registered[frame] then return true end
        frame=frame.GetParent and frame:GetParent() or nil
    end
    return false
end
-- Freeze resolved native positions, not raw preset placeholders. Blizzard's
-- automatic bar manager gives several default bars the SAME preset anchor and
-- only stacks them after UpdateSystems has run.
function app:ResolveBlizzardHUD(preset)
    local m=manager(); local result=copy(preset); result.fdsResolved=true
    local registered,systems={},{}
    for _,system in ipairs(result.systems or {}) do
        local f=m:GetRegisteredSystemFrame(system.system,system.systemIndex)
        if f then registered[f]=true; systems[f]=system end
    end
    local count,fallback=0,0
    for _,system in ipairs(result.systems or {}) do
        local f=m:GetRegisteredSystemFrame(system.system,system.systemIndex)
        local a
        if f and f:GetNumPoints()>0 then
            local p,r,rp,ox,oy=f:GetPoint(1); local relative=name(r)
            if relative=="UIParent" or r==UIParent or r==WorldFrame or relative=="WorldFrame" or registeredParent(r,registered) then
                -- PrepareForSave/ApplySystemAnchor use local frame scale here.
                a={point=p,relativeTo=relative or "UIParent",relativePoint=rp,offsetX=(ox or 0)*f:GetScale(),offsetY=(oy or 0)*f:GetScale()}
                if f:GetNumPoints()>1 then
                    local p2,r2,rp2,x2,y2=f:GetPoint(2)
                    if name(r2)=="UIParent" or r2==UIParent or registeredParent(r2,registered) then
                        system.anchorInfo2={point=p2,relativeTo=name(r2) or "UIParent",relativePoint=rp2,offsetX=(x2 or 0)*f:GetScale(),offsetY=(y2 or 0)*f:GetScale()}
                    end
                end
            else
                -- External managed containers stay sized to the full window.
                -- Resolve their actual rectangle without moving the container.
                local left,bottom,width,height=f:GetRect()
                if left and bottom then
                    local factor=f:GetEffectiveScale()/UIParent:GetEffectiveScale()
                    local cx,cy=(left+width/2)*factor,(bottom+height/2)*factor
                    local original=system.anchorInfo
                    local pivot=original and original.relativeTo=="UIParent" and pivots[original.relativePoint]
                    if not pivot then pivot={cx<UIParent:GetWidth()/3 and 0 or cx>UIParent:GetWidth()*2/3 and 1 or 0.5,cy<UIParent:GetHeight()/3 and 1 or cy>UIParent:GetHeight()*2/3 and 0 or 0.5} end
                    local rpName; for n,v in pairs(pivots) do if v[1]==pivot[1] and v[2]==pivot[2] then rpName=n; break end end
                    a={point="CENTER",relativeTo="UIParent",relativePoint=rpName,offsetX=cx-pivot[1]*UIParent:GetWidth(),offsetY=cy-(1-pivot[2])*UIParent:GetHeight()}
                    system.anchorInfo2=nil
                end
            end
        end
        if a then system.anchorInfo=a; count=count+1 else fallback=fallback+1 end
        if not system.anchorInfo then error("Ancrage Blizzard indisponible pour le système "..key(system)) end
        system.isInDefaultPosition=false
    end
    -- Hidden automatic bars can still have their initialization anchor (0,0).
    -- Reserve non-overlapping slots above/beside the visible default stack.
    local function hiddenSlots(list,horizontal)
        local edge=horizontal and (MAIN_ACTION_BAR_DEFAULT_OFFSET_Y or 35) or 5
        for _,f in ipairs(list or {}) do
            if systems[f] and f:IsShown() then
                local l,b,w,h=f:GetRect(); local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale()
                if l and b then edge=math.max(edge,horizontal and (b+h)*ratio or UIParent:GetWidth()-l*ratio) end
            end
        end
        for _,f in ipairs(list or {}) do
            if systems[f] and not f:IsShown() then
                local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale()
                local gap=horizontal and (BOTTOM_ACTION_BARS_SPACER_Y or 4) or 5
                systems[f].anchorInfo={point=horizontal and "BOTTOM" or "RIGHT",relativeTo="UIParent",relativePoint=horizontal and "BOTTOM" or "RIGHT",offsetX=horizontal and 0 or -edge-gap,offsetY=horizontal and edge+gap or (RIGHT_ACTION_BAR_DEFAULT_OFFSET_Y or -77)}
                systems[f].anchorInfo2=nil
                edge=edge+gap+(horizontal and f:GetHeight() or f:GetWidth())*ratio
            end
        end
    end
    hiddenSlots(m.GetBottomActionBars and m:GetBottomActionBars(),true)
    hiddenSlots(m.GetRightActionBars and m:GetRightActionBars(),false)
    return result,count,fallback
end
function app:RestoreBlizzardHUD(requestedIndex)
    local reason=ready(); if reason then self:HUDNotice(reason); return false end
    if self.blizzardHUDJob then self:HUDNotice("La restauration du HUD est déjà en cours."); return false end
    local stamp=signature()
    if not self.db.enabled or not stamp then self:HUDNotice("Active d'abord le double écran et son cadrage, puis restaure le HUD Blizzard."); return false end
    if not C_EditMode or not C_EditMode.SaveLayouts or not C_EditMode.OnLayoutAdded then self:HUDNotice("Les fonctions natives de sauvegarde ne sont pas disponibles."); return false end
    local m=manager(); local preset,index
    local defaultIndex=Constants and Constants.EditModeLayoutConsts and Constants.EditModeLayoutConsts.EditModeDefaultLayout
    local kind=Enum and Enum.EditModeLayoutType and Enum.EditModeLayoutType.Preset
    for i,layout in ipairs(m.layoutInfo.layouts) do
        if layout.layoutType==kind and (requestedIndex and i==requestedIndex or not requestedIndex and (not preset or layout.layoutIndex==defaultIndex)) then
            preset=layout; index=i
            if requestedIndex or layout.layoutIndex==defaultIndex then break end
        end
    end
    if not preset then self:HUDNotice("Aucune disposition Blizzard par défaut n'est disponible sur ce client."); return false end
    local previous=m.layoutInfo.layouts[m.layoutInfo.activeLayout]
    if self.ReleaseAncillaryHUD then self:ReleaseAncillaryHUD() end
    local job={signature=stamp,preset=copy(preset),index=index,previous=previous and previous.layoutName}
    self.blizzardHUDJob=job
    local function finish()
        if app.blizzardHUDJob~=job then return end
        if InCombatLockdown() then
            app.pending["HUD Blizzard"]=finish; app:HUDNotice("Restauration du HUD suspendue jusqu'à la fin du combat."); return
        end
        local active=manager() and manager().layoutInfo.layouts[manager().layoutInfo.activeLayout]
        if not app.db.enabled or signature()~=job.signature or not active or active.layoutName~=job.preset.layoutName or ready() then
            app.blizzardHUDJob=nil; app:HUDNotice("Restauration annulée : l'affichage ou le mode Édition a changé. Relance-la une fois l'affichage stabilisé."); return
        end
        local ok,success=pcall(function()
            local resolved,count,fallback=app:ResolveBlizzardHUD(job.preset)
            local layout,err=app:BuildHUDLayout(resolved,nil,job.index)
            if not layout then error(err) end
            if not app:StoreNativeHUD(layout,job.preset.layoutName,"blizzard") then job.failure=app.lastHUDNotice; return false end
            app:GetHUDState().blizzardPresetName=job.preset.layoutName
            app:GetHUDState().blizzardSignature=job.signature
            app:Record("HUD Blizzard : "..count.." ancrages résolus, "..fallback.." ancrages de préréglage.")
            return true
        end)
        app.blizzardHUDJob=nil
        if not ok or not success then
            -- Restore the previously selected layout on failure, without deleting it.
            for i,layout in ipairs(manager().layoutInfo.layouts) do if layout.layoutName==job.previous then pcall(C_EditMode.SetActiveLayout,i); break end end
            app:Apply()
            app:HUDNotice("Le HUD Blizzard n'a pas été restauré : "..tostring(ok and (job.failure or "sauvegarde refusée") or success)); return
        end
        app:Apply()
        app:HUDNotice("HUD Blizzard rétabli sur l'écran du jeu : "..job.preset.layoutName..". Les dispositions personnelles sont conservées. Fais /reload pour vérifier les cadres protégés.")
    end
    local ok,err=pcall(C_EditMode.SetActiveLayout,index)
    if not ok then self.blizzardHUDJob=nil; self:HUDNotice("Le client a refusé le préréglage : "..tostring(err)); return false end
    self:HUDNotice("Chargement du HUD Blizzard et calcul de ses positions pour l'écran du jeu…")
    C_Timer.After(0.1,finish)
    return true
end
function app:ResumeNativeHUD()
    if self.blizzardHUDJob or self.hudWriteInProgress or self.hudResumeBusy then return end
    if not self.db.hud or not self:Bridge() then return end
    local m=manager(); if not m or ready() then return end
    local s=self:GetHUDState(); local active=m.layoutInfo.layouts[m.layoutInfo.activeLayout]
    if not active or active.layoutName~=s.sourceName then return end
    local current=signature()
    local function same(a,b)
        if a==b then return true end
        if type(a)~="string" or type(b)~="string" then return false end
        local x,y={},{}; for n in a:gmatch("[^:]+") do x[#x+1]=tonumber(n) end; for n in b:gmatch("[^:]+") do y[#y+1]=tonumber(n) end
        if #x~=#y then return false end
        for i=1,#x do if not x[i] or not y[i] or math.abs(x[i]-y[i])>0.05 then return false end end
        return true
    end
    if s.mode=="blizzard" and not same(s.blizzardSignature,current) then
        self:HUDNotice("L'affichage a changé. Utilise Restaurer l'origine pour recalculer le HUD Blizzard."); return
    end
    for i,layout in ipairs(m.layoutInfo.layouts) do
        if layout.layoutName==s.generatedName then
            self.hudResumeBusy=true
            local ok,err=pcall(C_EditMode.SetActiveLayout,i)
            self.hudResumeBusy=false
            if not ok then self:Record("Reprise du HUD refusée : "..tostring(err)) end
            return
        end
    end
end
