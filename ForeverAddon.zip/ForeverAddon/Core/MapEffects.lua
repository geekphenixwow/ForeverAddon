local _,app=...
-- Only the map we manage is affected. Never change UIParent alpha or game gamma.
function app:SyncWorkspaceMap(active)
    local map=WorldMapFrame; if not map then return end
    active=active and self.db.enabled and self.db.panels.WorldMapFrame and self.viewportActive
    local function suppress()
        if not app.mapEffectsActive then return end
        local blackout=map.BlackoutFrame
        if blackout then blackout:SetAlpha(0); blackout:Hide() end
        if PlayerMovementFrameFader and PlayerMovementFrameFader.RemoveFrame then PlayerMovementFrameFader.RemoveFrame(map) end
        -- Classic clients use UIFrameFade rather than PlayerMovementFrameFader.
        if UIFrameFadeRemoveFrame then UIFrameFadeRemoveFrame(map) end
        map.fadeOut=false
        if map.AlphaOut and map.AlphaOut.Stop then map.AlphaOut:Stop() end
        if map.AlphaIn and map.AlphaIn.Stop then map.AlphaIn:Stop() end
        map:SetAlpha(1)
    end
    if active then
        if not self.mapEffectsActive then
            self.mapOriginalAlpha=map:GetAlpha()
            if map.BlackoutFrame then self.mapBlackoutAlpha=map.BlackoutFrame:GetAlpha() end
        end
        self.mapEffectsActive=true
        if not self.mapEffectsHooked then
            self.mapEffectsHooked=true
            map:HookScript("OnShow",function() C_Timer.After(0,suppress) end)
            if map.BlackoutFrame then map.BlackoutFrame:HookScript("OnShow",suppress) end
            -- Native OnShow can register its fade *after* another OnShow hook.
            -- Movement events recheck it without a frame-by-frame polling loop.
            local listener=CreateFrame("Frame")
            listener:RegisterEvent("PLAYER_STARTED_MOVING"); listener:RegisterEvent("PLAYER_STOPPED_MOVING")
            listener:SetScript("OnEvent",suppress)
            self.mapEffectsListener=listener
        end
        suppress()
    elseif self.mapEffectsActive then
        self.mapEffectsActive=false
        map:SetAlpha(self.mapOriginalAlpha or 1)
        if map.BlackoutFrame then
            map.BlackoutFrame:SetAlpha(self.mapBlackoutAlpha or 1)
            map.BlackoutFrame:SetShown(map:IsShown() and map.IsMaximized and map:IsMaximized() or false)
        end
        -- Restore the native fade registration via its normal OnShow next time.
        -- While still visible, use the native registration contract if available.
        if map:IsShown() and PlayerMovementFrameFader and PlayerMovementFrameFader.AddDeferredFrame then
            PlayerMovementFrameFader.AddDeferredFrame(map,0.5,1,0.5,function() return GetCVarBool("mapFade") and not map:IsMouseOver() end)
        end
    end
end
