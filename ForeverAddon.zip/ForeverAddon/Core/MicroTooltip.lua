local _,app=...
local owners={"MainMenuMicroButton","HelpMicroButton","MainMenuBarPerformanceBarFrame","MainMenuBarPerformanceBarFrameButton"}
local function isMicroButton(owner)
    if not owner then return false end
    for _,name in ipairs(owners) do if _G[name] and owner==_G[name] then return true end end
    return false
end
function app:ReleaseMicroTooltip(restorePoints)
    local saved=self.microTooltipState
    if not saved or self.microTooltipBusy then return end
    if InCombatLockdown() then self.pending.infobulle=function() self:ReleaseMicroTooltip(restorePoints) end;return end
    if saved.tip.IsForbidden and saved.tip:IsForbidden() then self.microTooltipState=nil;return end
    self.microTooltipBusy=true; self.microTooltipState=nil
    saved.tip:SetScale(saved.scale)
    if restorePoints then
        saved.tip:ClearAllPoints()
        for _,p in ipairs(saved.points) do saved.tip:SetPoint(unpack(p,1,5)) end
    end
    self.microTooltipBusy=false
end
function app:AnchorMicroTooltip(tip)
    if self.microTooltipBusy or tip.IsForbidden and tip:IsForbidden() then return end
    if InCombatLockdown() then self.pending.infobulle=function() self:AnchorMicroTooltip(tip) end;return end
    local owner=tip:GetOwner()
    if not self.db.enabled or not self.viewportActive or not isMicroButton(owner) then self:ReleaseMicroTooltip(false); return end
    if not tip:IsShown() then return end
    local x,y,w,h=self:Area("game"); if not x then self:ReleaseMicroTooltip(false); return end
    local left,bottom,bw,bh=owner:GetRect()
    if not left or not bottom or not bw or not bh or tip:GetWidth()<=0 or tip:GetHeight()<=0 then return end
    if self.microTooltipState and self.microTooltipState.owner~=owner then self:ReleaseMicroTooltip(false) end
    if not self.microTooltipState then
        local points={}; for i=1,tip:GetNumPoints() do points[i]={tip:GetPoint(i)} end
        self.microTooltipState={tip=tip,owner=owner,points=points,scale=tip:GetScale()}
    end
    self.microTooltipBusy=true
    -- Compute from the saved scale every time so repeated native refreshes
    -- cannot shrink the tooltip progressively.
    tip:SetScale(self.microTooltipState.scale)
    local uiScale=UIParent:GetEffectiveScale()
    local ratio=tip:GetEffectiveScale()/uiScale
    local tw,th=tip:GetWidth()*ratio,tip:GetHeight()*ratio
    local fit=math.min(1,math.max(1,w-16)/tw,math.max(1,h-16)/th)
    if fit<1 then tip:SetScale(self.microTooltipState.scale*fit); ratio=tip:GetEffectiveScale()/uiScale; tw,th=tip:GetWidth()*ratio,tip:GetHeight()*ratio end
    local buttonRatio=owner:GetEffectiveScale()/uiScale
    local gameBottom=UIParent:GetHeight()+y-h
    local gameTop=UIParent:GetHeight()+y
    local tx=(left+bw/2)*buttonRatio-tw/2
    local ty=(bottom+bh)*buttonRatio+8
    if ty+th>gameTop-8 then ty=bottom*buttonRatio-th-8 end
    tx=math.max(x+8,math.min(tx,x+w-tw-8))
    ty=math.max(gameBottom+8,math.min(ty,gameTop-th-8))
    tip:ClearAllPoints(); tip:SetPoint("BOTTOMLEFT",UIParent,"BOTTOMLEFT",tx/ratio,ty/ratio)
    self.microTooltipBusy=false
end
function app:QueueMicroTooltip(tip,hide)
    if self.microTooltipBusy then return end
    if hide then self.microTooltipHideQueued=true end
    if self.microTooltipQueued then return end
    self.microTooltipQueued=true
    C_Timer.After(0,function()
        app:Safe("infobulle Blizzard",function()
            local ok,err=pcall(function()
                if app.microTooltipHideQueued then app.microTooltipHideQueued=nil;app:ReleaseMicroTooltip(true) end
                app:AnchorMicroTooltip(tip)
            end)
            app.microTooltipBusy=false
            if not ok then error(err) end
        end)
        app.microTooltipQueued=false
    end)
end
function app:InitMicroTooltip()
    local tip=GameTooltip
    if self.microTooltipHooked or not tip or tip.IsForbidden and tip:IsForbidden() or not tip.HookScript or not tip.GetOwner or not hooksecurefunc then return end
    self.microTooltipHooked=true
    tip:HookScript("OnShow",function() app:QueueMicroTooltip(tip) end)
    tip:HookScript("OnSizeChanged",function() app:QueueMicroTooltip(tip) end)
    tip:HookScript("OnHide",function() app:QueueMicroTooltip(tip,true) end)
    -- The performance tooltip is rebuilt by Blizzard while hovered. Post-hooks
    -- keep its native contents and handlers while correcting only its position.
    hooksecurefunc(tip,"SetPoint",function() app:QueueMicroTooltip(tip) end)
    hooksecurefunc(tip,"SetOwner",function() app:QueueMicroTooltip(tip) end)
end
