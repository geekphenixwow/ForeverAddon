local _,app=...
local anchors={TOPLEFT={0,0},TOP={0.5,0},TOPRIGHT={1,0},LEFT={0,0.5},CENTER={0.5,0.5},RIGHT={1,0.5},BOTTOMLEFT={0,1},BOTTOM={0.5,1},BOTTOMRIGHT={1,1}}
local function copy(v)
    if type(v)~="table" then return v end
    local out={}; for k,item in pairs(v) do out[k]=copy(item) end; return out
end
local function state()
    app.db.hudCharacters=app.db.hudCharacters or {}
    local key=UnitGUID and UnitGUID("player") or "local"
    app.db.hudCharacters[key]=app.db.hudCharacters[key] or {}
    return app.db.hudCharacters[key]
end
local function manager()
    local m=EditModeManagerFrame
    if not m or not m.layoutInfo or not m.layoutInfo.layouts or not C_EditMode then return nil end
    return m
end
function app:GetHUDState() return state() end
local function blocked()
    if InCombatLockdown() then return "Attends la fin du combat." end
    local m=manager()
    if not m then return "Le mode Édition n'est pas encore disponible." end
    if m:IsShown() then return "Ferme et enregistre le mode Édition avant de continuer." end
    if m.HasActiveChanges and m:HasActiveChanges() then return "Enregistre les modifications du mode Édition avant de continuer." end
end
local function generated(name)
    local n=(name or ""):lower():gsub("%s","")
    return n:find("foreveraddon",1,true) or n:find("offhand",1,true) or n:find("fds-hud",1,true)
end
function app:HUDSources()
    local result={}; local m=manager(); if not m then return result end
    for index,layout in ipairs(m.layoutInfo.layouts) do
        if not generated(layout.layoutName) then result[#result+1]={index=index,layout=layout} end
    end
    return result
end
function app:HUDNotice(message)
    self.lastHUDNotice=message
    if self.hudAssistant then self.hudAssistant.notice:SetText(message) end
    if self.options then self:RefreshOptions() end
    self:Message(message)
end
function app:SelectHUDOrigin(name)
    local reason=blocked(); if reason then self:HUDNotice(reason); return false end
    local m=manager()
    for _,entry in ipairs(self:HUDSources()) do
        if entry.layout.layoutName==name then
            self.db.hud=false
            -- Restore only live fallback transforms before the native manager reloads.
            for frame in pairs(self.hudFrames) do self:RestoreFrame(frame); self.frames[frame]=nil end
            self.hudFrames={}
            local s=state(); s.sourceName=name
            C_EditMode.SetActiveLayout(entry.index)
            self:HUDNotice("Disposition d'origine chargée : "..name..". Pour la mémoriser exactement, restaure d'abord WoW sur un écran dans le compagnon.")
            return true
        end
    end
    self:HUDNotice("Choisis une disposition d'origine dans la liste."); return false
end
function app:CaptureHUDOrigin(name)
    local reason=blocked(); if reason then self:HUDNotice(reason); return false end
    if self:Bridge() then self:HUDNotice("Restaure d'abord la fenêtre sur un seul écran avec le compagnon, puis mémorise ton interface."); return false end
    local known=self:CompanionData() or self.db.cachedBridge or self.db.manualBridge
    if known and known.game and math.abs(UIParent:GetWidth()/UIParent:GetHeight()-known.game.w/known.game.h)>0.01 then
        self:HUDNotice("L'interface n'a pas encore les proportions de l'écran du jeu. Restaure la fenêtre et attends son redimensionnement."); return false
    end
    local m=manager(); local source=m.layoutInfo.layouts[m.layoutInfo.activeLayout]
    if not source or source.layoutName~=name or generated(name) then self:HUDNotice("Charge d'abord la disposition d'origine choisie."); return false end
    local snapshot={layout=copy(source),anchors={},external={},uiScale=UIParent:GetEffectiveScale()}
    for _,system in ipairs(source.systems or {}) do
        local f=m.GetRegisteredSystemFrame and m:GetRegisteredSystemFrame(system.system,system.systemIndex)
        if f and f:GetNumPoints()>0 then
            local p,relative,rp,ox,oy=f:GetPoint(1)
            if relative==UIParent or relative=="UIParent" then
                local key=tostring(system.system)..":"..tostring(system.systemIndex)
                snapshot.anchors[key]={point=p,relativeTo="UIParent",relativePoint=rp,offsetX=ox,offsetY=oy,ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale()}
            elseif relative==ChatFrame1 or relative=="ChatFrame1" then
                local left,bottom,width,height=f:GetRect()
                if left and bottom then
                    local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale()
                    local key=tostring(system.system)..":"..tostring(system.systemIndex)
                    snapshot.external[key]={point="TOPLEFT",relativeTo="UIParent",relativePoint="TOPLEFT",offsetX=left,offsetY=bottom+height-UIParent:GetHeight()/ratio,ratio=ratio}
                end
            end
        end
    end
    local s=state(); s.sourceName=name; s.snapshot=snapshot
    self:HUDNotice("Interface mémorisée. Étends WoW dans le compagnon, puis clique sur Adapter le HUD.")
    return true
end
function app:BuildHUDLayout(source,snapshot,sourceIndex)
    local m=manager(); local x,y,w,h=self:Area("game")
    if not x then return nil,"Étends d'abord WoW dans le compagnon et recharge l'interface." end
    local fullW,fullH=UIParent:GetWidth(),UIParent:GetHeight()
    local result=copy(snapshot and snapshot.layout or source)
    for _,system in ipairs(result.systems or {}) do
        local f=m.GetRegisteredSystemFrame and m:GetRegisteredSystemFrame(system.system,system.systemIndex)
        local key=tostring(system.system)..":"..tostring(system.systemIndex)
        local saved=snapshot and (snapshot.anchors[key] or self.db.panels.ChatFrame1 and snapshot.external and snapshot.external[key])
        local a=saved and copy(saved) or copy(system.anchorInfo)
        if not source.fdsResolved and not saved and (system.isInDefaultPosition or source.layoutType==(Enum and Enum.EditModeLayoutType and Enum.EditModeLayoutType.Preset)) then
            if EditModePresetLayoutManager and EditModePresetLayoutManager.GetPresetLayoutSystemAnchorInfo then
                local preset=source.layoutIndex or (source.layoutType==Enum.EditModeLayoutType.Preset and sourceIndex) or (Constants and Constants.EditModeLayoutConsts and Constants.EditModeLayoutConsts.EditModeDefaultLayout) or 1
                a=copy(EditModePresetLayoutManager:GetPresetLayoutSystemAnchorInfo(preset,system.system,system.systemIndex))
            end
        end
        local root=a and (a.relativeTo=="UIParent" or a.relativeTo=="")
        if root and anchors[a.relativePoint] then
            local pos=anchors[a.relativePoint]
            local ox,oy=a.offsetX or 0,a.offsetY or 0
            -- Saved Edit Mode offsets are UI units. Blizzard divides these by
            -- the frame's own scale in ApplySystemAnchor; do not divide twice.
            if saved then ox=ox*saved.ratio; oy=oy*saved.ratio end
            a.offsetX=ox+x+pos[1]*w-pos[1]*fullW
            a.offsetY=oy+y-pos[2]*h+pos[2]*fullH
            a.ratio=nil; a.relativeTo="UIParent"
            system.anchorInfo=a; system.isInDefaultPosition=false
        end
        local second=system.anchorInfo2
        if second and (second.relativeTo=="UIParent" or second.relativeTo=="") and anchors[second.relativePoint] then
            local pos=anchors[second.relativePoint]
            second.offsetX=(second.offsetX or 0)+x+pos[1]*w-pos[1]*fullW
            second.offsetY=(second.offsetY or 0)+y-pos[2]*h+pos[2]*fullH
        end
        -- Relative anchors must also leave the automatic default-frame manager.
        if a then system.anchorInfo=a; system.isInDefaultPosition=false end
    end
    result.fdsResolved=nil
    return result
end
function app:CreateNativeHUD(name)
    local reason=blocked(); if reason then self:HUDNotice(reason); return false end
    if not C_EditMode.SaveLayouts or not C_EditMode.OnLayoutAdded then self:HUDNotice("Ce client ne propose pas les fonctions de sauvegarde nécessaires."); return false end
    local m=manager(); local entry
    for _,candidate in ipairs(self:HUDSources()) do if candidate.layout.layoutName==name then entry=candidate; break end end
    if not entry then self:HUDNotice("Choisis une disposition d'origine, pas une ancienne disposition double écran."); return false end
    if entry.layout.layoutType==(Enum and Enum.EditModeLayoutType and Enum.EditModeLayoutType.Preset) and self.RestoreBlizzardHUD then return self:RestoreBlizzardHUD(entry.index) end
    local s=state(); local snapshot=s.snapshot and s.snapshot.layout.layoutName==name and s.snapshot or nil
    local result,err=self:BuildHUDLayout(entry.layout,snapshot,entry.index)
    if not result then self:HUDNotice(err); return false end
    return self:StoreNativeHUD(result,name,"custom")
end
function app:StoreNativeHUD(result,name,mode)
    local reason=blocked(); if reason then self:HUDNotice(reason); return false end
    local m=manager(); local s=state()
    local kind=Enum and Enum.EditModeLayoutType and Enum.EditModeLayoutType.Character
    if kind==nil then self:HUDNotice("Type de disposition personnage indisponible."); return false end
    local info=copy(m.layoutInfo); local index
    -- Never overwrite an unrelated same-name layout. Rebuild only our recorded copy.
    for i,layout in ipairs(info.layouts) do
        if s.generatedName and layout.layoutName==s.generatedName and layout.layoutType==kind then index=i; break end
    end
    local new=index==nil
    if new then
        local count=0; for _,layout in ipairs(info.layouts) do if layout.layoutType==kind then count=count+1 end end
        local limit=Constants and Constants.EditModeConsts and Constants.EditModeConsts.EditModeMaxLayoutsPerType or 5
        if count>=limit then self:HUDNotice("Le nombre maximal de dispositions personnage est atteint. Libère une place dans le mode Édition."); return false end
        index=#info.layouts+1
        local serial=1; local used={}; for _,layout in ipairs(info.layouts) do used[layout.layoutName]=true end
        local label="FDS - HUD jeu"
        while used[label] do serial=serial+1; label="FDS - HUD jeu "..serial end
        result.layoutName=label
    else result.layoutName=s.generatedName end
    result.layoutType=kind; result.layoutIndex=nil
    info.layouts[index]=result
    self.hudWriteInProgress=true
    local ok,failure=pcall(function()
        C_EditMode.SaveLayouts(info)
        if new then C_EditMode.OnLayoutAdded(index,true,false) else C_EditMode.SetActiveLayout(index) end
    end)
    self.hudWriteInProgress=false
    if not ok then self:HUDNotice("Le client a refusé la disposition : "..tostring(failure)); return false end
    s.sourceName=name; s.generatedName=result.layoutName; s.mode=mode; self.db.hud=true
    self:Apply(); self:HUDNotice("Copie du HUD créée : "..result.layoutName..". La disposition d'origine est conservée. Recharge l'interface pour vérifier les cadres protégés.")
    return true
end
function app:RestoreNativeHUD(explicit)
    local m=manager(); if not m or self.hudWriteInProgress then return end
    local s=state(); local active=m.layoutInfo.layouts[m.layoutInfo.activeLayout]
    if not s.sourceName or not active or not explicit and active.layoutName~=s.generatedName then return end
    local wanted=self.db.hud
    self:SelectHUDOrigin(s.sourceName)
    if not explicit then self.db.hud=wanted end
end
function app:SetHUDEnabled(value)
    self.db.hud=value
    if not value then self:RestoreNativeHUD(false)
    elseif manager() then
        local s=state()
        if s.mode=="blizzard" then self:RestoreBlizzardHUD()
        else self:ShowHUDAssistant() end
    end
    self:Apply()
end
function app:ShowHUDAssistant()
    if self.hudAssistant then self.hudAssistant:Show(); self.hudAssistant.refresh(); return end
    local f=CreateFrame("Frame","FDSHUDAssistant",UIParent,"BackdropTemplate"); self.hudAssistant=f
    f:SetSize(760,300); f:SetFrameStrata("FULLSCREEN_DIALOG"); self:LayoutHUDAssistant()
    f:EnableMouse(true); f:SetClampedToScreen(true)
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=24})
    f:SetBackdropColor(0.025,0.035,0.045,1)
    local function label(value,x,y,w)
        local t=f:CreateFontString(nil,"OVERLAY","GameFontHighlight"); t:SetPoint("TOPLEFT",x,y); t:SetWidth(w); t:SetJustifyH("LEFT"); t:SetText(value); return t
    end
    local function button(value,x,y,w,fn)
        local b=CreateFrame("Button",nil,f,"UIPanelButtonTemplate"); b:SetPoint("TOPLEFT",x,y); b:SetSize(w,32); b:SetText(value); b:SetScript("OnClick",fn); return b
    end
    label("Forever Addon — Assistance de placement du HUD",28,-25,690)
    label("Rétablit le préréglage Blizzard sur l'écran du jeu 3D, sans effacer les positions de la carte et des sacs. Garde le double écran actif, puis clique sur Restaurer l'origine.",28,-61,690)
    local sourceLabel=label("",28,-119,690)
    function f.refresh()
        local m=manager(); local active=m and m.layoutInfo.layouts[m.layoutInfo.activeLayout]
        sourceLabel:SetText("Disposition actuelle : "..(active and active.layoutName or "en attente du jeu"))
    end
    f.notice=label("Action à effectuer hors combat, mode Édition enregistré et fermé.",28,-158,690)
    button("Restaurer l'origine",28,-242,330,function() app:RestoreBlizzardHUD(); f.refresh() end)
    button("Fermer",390,-242,330,function() f:Hide() end)
    table.insert(UISpecialFrames,"FDSHUDAssistant"); f.refresh()
end
function app:LayoutHUDAssistant()
    local f=self.hudAssistant; if not f then return end
    local x,y,w,h=self:Area("game")
    f:SetScale(math.max(0.2,math.min(1,((w or UIParent:GetWidth())-40)/760,((h or UIParent:GetHeight())-40)/300)))
    f:ClearAllPoints()
    if x then
        local ratio=UIParent:GetEffectiveScale()/f:GetEffectiveScale()
        f:SetPoint("CENTER",UIParent,"TOPLEFT",(x+w/2)*ratio,(y-h/2)*ratio)
    else f:SetPoint("CENTER",UIParent,"CENTER",0,0) end
end
