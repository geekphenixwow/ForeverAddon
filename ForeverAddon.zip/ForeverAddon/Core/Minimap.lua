local _, app = ...
local TWO_PI=2*math.pi
local function setAngleFromCursor()
    if InCombatLockdown() then app.minimapButton:SetScript("OnUpdate",nil); return end
    local cx,cy=Minimap:GetCenter()
    if not cx or not cy then return end
    local x,y=GetCursorPosition()
    local scale=Minimap:GetEffectiveScale()
    x,y=x/scale-cx,y/scale-cy
    if x==0 and y==0 then return end
    local angle
    if x==0 then angle=y>0 and math.pi/2 or -math.pi/2
    else angle=math.atan(y/x); if x<0 then angle=angle+math.pi end end
    app.db.minimapAngle=(angle%TWO_PI)*180/math.pi
    app:PositionMinimapButton()
end
function app:PositionMinimapButton()
    if not self.minimapButton then return end
    local angle=(tonumber(self.db.minimapAngle) or 225)*math.pi/180
    local radiusX=Minimap:GetWidth()/2+10
    local radiusY=Minimap:GetHeight()/2+10
    self.minimapButton:ClearAllPoints()
    self.minimapButton:SetPoint("CENTER",Minimap,"CENTER",math.cos(angle)*radiusX,math.sin(angle)*radiusY)
end
function app:UpdateMinimapStatus()
    local t=self.minimapStatusDot
    if not t then return end
    local valid=self.db and self.db.enabled and self.viewportActive and self:Bridge()
    self.minimapStatusActive=valid and true or false
    if valid then t:SetVertexColor(0.12,1,0.25,1)
    else t:SetVertexColor(1,0.15,0.12,1) end
end
function app:CreateMinimapButton()
    if self.minimapButton or not Minimap then return end
    self:Safe("icone-minicarte",function()
        if self.minimapButton then return end
        local b=CreateFrame("Button","FDSLocalMinimapButton",Minimap,"BackdropTemplate")
        b:SetSize(32,32); b:SetFrameStrata("MEDIUM"); b:SetFrameLevel(Minimap:GetFrameLevel()+8)
        b:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
        b:SetBackdropColor(0.025,0.055,0.08,1); b:SetBackdropBorderColor(0.72,0.57,0.22,1)
        local logo=b:CreateTexture(nil,"ARTWORK")
        logo:SetTexture("Interface\\AddOns\\ForeverAddon\\Media\\NexusSmall.tga");logo:SetSize(30,30);logo:SetPoint("CENTER",b,"CENTER",0,0)
        local halo=b:CreateTexture(nil,"OVERLAY",nil,1)
        halo:SetTexture("Interface\\CHARACTERFRAME\\TempPortraitAlphaMask")
        halo:SetSize(10,10);halo:SetPoint("TOPRIGHT",b,"TOPRIGHT",1,1);halo:SetVertexColor(0.015,0.02,0.025,1)
        local dot=b:CreateTexture(nil,"OVERLAY",nil,2)
        dot:SetTexture("Interface\\CHARACTERFRAME\\TempPortraitAlphaMask")
        dot:SetSize(7,7);dot:SetPoint("CENTER",halo,"CENTER",0,0)
        self.minimapStatusDot=dot
        b:RegisterForClicks("LeftButtonUp","RightButtonUp"); b:RegisterForDrag("LeftButton")
        b:SetScript("OnClick",function()
            if b.suppressClick then b.suppressClick=nil; return end
            if app.options and app.options:IsShown() then app.options:Hide() else app:ShowOptions() end
        end)
        b:SetScript("OnEnter",function()
            GameTooltip:SetOwner(b,"ANCHOR_LEFT")
            app:UpdateMinimapStatus()
            GameTooltip:SetText("Forever Addon")
            GameTooltip:AddLine(app.minimapStatusActive and "Voyant vert : cadrage double écran actif." or "Voyant rouge : cadrage désactivé ou non valide.",1,1,1)
            GameTooltip:AddLine("Cliquer : ouvrir ou fermer les réglages.",1,1,1)
            GameTooltip:AddLine("Glisser : déplacer l’icône autour de la minicarte.",1,1,1)
            GameTooltip:Show()
        end)
        b:SetScript("OnLeave",function() GameTooltip:Hide() end)
        b:SetScript("OnDragStart",function()
            if InCombatLockdown() then return end
            b.suppressClick=true
            GameTooltip:Hide()
            b:SetScript("OnUpdate",setAngleFromCursor)
        end)
        b:SetScript("OnDragStop",function()
            b:SetScript("OnUpdate",nil)
            -- Some clients emit a click after dragging; do not open the menu on that click.
            C_Timer.After(0,function() b.suppressClick=nil end)
        end)
        b:SetScript("OnHide",function() b:SetScript("OnUpdate",nil) end)
        self.minimapButton=b; self:PositionMinimapButton(); self:UpdateMinimapStatus(); b:SetShown(not self.db.minimapHidden)
    end)
end
