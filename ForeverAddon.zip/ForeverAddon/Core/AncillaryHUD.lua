local _,app=...
local names={"UIErrorsFrame","RaidWarningFrame","RaidBossEmoteFrame","MirrorTimer1","MirrorTimer2","MirrorTimer3","DurabilityFrame","PlayerPowerBarAlt","ExtraAbilityContainer","ZoneAbilityFrame","AlertFrame","TalkingHeadFrame","VehicleSeatIndicator","TotemFrame"}
local anchors={TOPLEFT={0,0},TOP={0.5,0},TOPRIGHT={1,0},LEFT={0,0.5},CENTER={0.5,0.5},RIGHT={1,0.5},BOTTOMLEFT={0,1},BOTTOM={0.5,1},BOTTOMRIGHT={1,1}}
app.ancillarySnapshots={}; app.ancillaryHooks={}
local function points(f) local p={}; for i=1,f:GetNumPoints() do p[i]={f:GetPoint(i)} end; return p end
local function nativeOwned(f)
    if f.system~=nil then return true end
    local m=EditModeManagerFrame
    for _,registered in ipairs(m and m.registeredSystemFrames or {}) do
        local parent=registered
        for i=1,12 do
            if parent==f then return true end
            if not parent or parent==UIParent then break end
            parent=parent.GetParent and parent:GetParent() or nil
        end
    end
    return false
end
function app:ReleaseAncillaryHUD()
    for frame,snapshot in pairs(self.ancillarySnapshots) do
        self:Safe("restaurer HUD secondaire:"..tostring(frame),function()
            if frame.IsForbidden and frame:IsForbidden() then return end
            self.ancillaryBusy=true
            local ok,err=pcall(function()
                frame:ClearAllPoints()
                for _,p in ipairs(snapshot) do frame:SetPoint(unpack(p,1,5)) end
            end)
            self.ancillaryBusy=false
            if not ok then error(err) end
            self.ancillarySnapshots[frame]=nil
        end)
    end
end
function app:PlaceAncillaryHUD(frame)
    if not self:IsBlizzardHUDActive() or nativeOwned(frame) or frame.IsForbidden and frame:IsForbidden() then return end
    self:Safe("HUD non éditable:"..tostring(frame),function()
        if not self:IsBlizzardHUDActive() or nativeOwned(frame) then return end
        local source=self.ancillarySnapshots[frame] or points(frame)
        if #source==0 then return end
        for _,p in ipairs(source) do
            if (p[2]~=UIParent and p[2]~="UIParent") or not anchors[p[3]] then return end
        end
        self.ancillarySnapshots[frame]=source
        local x,y,w,h=self:Area("game"); if not x then return end
        local ratio=UIParent:GetEffectiveScale()/frame:GetEffectiveScale()
        self.ancillaryBusy=true
        local ok,err=pcall(function()
            frame:ClearAllPoints()
            for _,p in ipairs(source) do
                local pivot=anchors[p[3]]
                frame:SetPoint(p[1],UIParent,p[3],(p[4] or 0)+(x+pivot[1]*w-pivot[1]*UIParent:GetWidth())*ratio,(p[5] or 0)+(y-pivot[2]*h+pivot[2]*UIParent:GetHeight())*ratio)
            end
        end)
        self.ancillaryBusy=false
        if not ok then error(err) end
    end)
end
function app:QueueAncillaryHUD(f,refresh)
    if self.ancillaryBusy or f.IsForbidden and f:IsForbidden() then return end
    if refresh then
        local ok,p=pcall(points,f)
        if ok then self.ancillarySnapshots[f]=self:IsBlizzardHUDActive() and p or nil end
    end
    self.ancillaryQueued=self.ancillaryQueued or {}
    if self.ancillaryQueued[f] then return end
    self.ancillaryQueued[f]=true
    C_Timer.After(0,function() app:PlaceAncillaryHUD(f);app.ancillaryQueued[f]=nil end)
end
function app:ApplyAncillaryHUD()
    if not self:IsBlizzardHUDActive() then self:ReleaseAncillaryHUD(); return end
    for _,name in ipairs(names) do
        local f=_G[name]
        if f and not nativeOwned(f) and not (f.IsForbidden and f:IsForbidden()) then
            if not self.ancillaryHooks[f] then
                self.ancillaryHooks[f]=true
                f:HookScript("OnShow",function() app:QueueAncillaryHUD(f) end)
                if hooksecurefunc then hooksecurefunc(f,"SetPoint",function()
                    app:QueueAncillaryHUD(f,true)
                end) end
            end
            self:PlaceAncillaryHUD(f)
        end
    end
end
