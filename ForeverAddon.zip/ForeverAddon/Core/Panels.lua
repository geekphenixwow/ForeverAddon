local _, app = ...
app.panels={}
-- Only known Blizzard top-level windows; never enumerate arbitrary UI frames.
app.panelCatalog={
 {"Carte du monde","WorldMapFrame"},{"Sacs Blizzard","ContainerFrameCombinedBags"},
 {"Personnage","CharacterFrame"},{"Discussion principale","ChatFrame1"},
 {"Hôtel des ventes","AuctionHouseFrame"},{"Hôtel des ventes classique","AuctionFrame"},
 {"Collections et apparences","CollectionsJournal"},{"Talents et spécialisations","PlayerSpellsFrame"},
 {"Talents classiques","PlayerTalentFrame"},{"Grimoire","SpellBookFrame"},
 {"Métiers","ProfessionsFrame"},{"Métiers classiques","TradeSkillFrame"},
 {"Artisanat classique","CraftFrame"},{"Banque","BankFrame"},
 {"Marchand","MerchantFrame"},{"Courrier","MailFrame"},{"Lettre ouverte","OpenMailFrame"},
 {"Échange","TradeFrame"},{"Dialogue des personnages","GossipFrame"},{"Dialogue de quête","QuestFrame"},
 {"Journal des quêtes classique","QuestLogFrame"},{"Maître de vol","TaxiFrame"},
 {"Maître de classe","ClassTrainerFrame"},{"Écurie","StableFrame"},{"Écurie classique","PetStableFrame"},
 {"Recherche de groupe","PVEFrame"},{"Recherche de groupe classique","LFGParentFrame"},
 {"Joueur contre joueur","PVPUIFrame"},{"Amis et social","FriendsFrame"},
 {"Guilde","GuildFrame"},{"Communautés","CommunitiesFrame"},{"Hauts faits","AchievementFrame"},
 {"Guide de l'aventurier","EncounterJournal"},{"Calendrier","CalendarFrame"},
 {"Transmogrification","WardrobeFrame"},
 {"Objets reçus","LootFrame"},
}
local names={}
for _,item in ipairs(app.panelCatalog) do names[#names+1]=item[2] end
for i=1,13 do names[#names+1]="ContainerFrame"..i end
local function wanted(name)
    if name:match("^ContainerFrame%d+$") then
        local f=_G[name]; local id=f and f.GetID and f:GetID()
        -- Bag frames are recycled for bank containers: never move those as held bags.
        if type(id)=="number" and (id<0 or id>(NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4)) then return false end
        return app.db.panels.ContainerFrameCombinedBags
    end
    return app.db.panels[name]
end
local function positionKey(name,f)
    local bagID=name:match("^ContainerFrame%d+$") and f.GetID and f:GetID()
    return type(bagID)=="number" and ("BagSlot"..bagID) or name
end
-- Save coordinates relative to the chosen monitor, not to the workspace alone.
function app:PanelAreaAt(left,top,width,height)
    local cx,cy=left+width/2,top-height/2
    local best,bestDistance
    for _,screen in ipairs({"game","workspace"}) do
        local x,y,w,h=self:Area(screen)
        if x then
            local dx=math.max(x-cx,0,cx-x-w)
            local dy=math.max(cy-y,0,y-h-cy)
            local distance=dx*dx+dy*dy
            if not bestDistance or distance<bestDistance then best,bestDistance=screen,distance end
        end
    end
    return best
end
function app:SavePanelPosition(name)
    local f=self.panels[name]
    if not f or f.IsForbidden and f:IsForbidden() or not self.db.enabled or not wanted(name) or not self:Bridge() then return false end
    local left,top=f:GetLeft(),f:GetTop()
    if type(left)~="number" or type(top)~="number" then return false end
    local ratio=f:GetEffectiveScale()/UIParent:GetEffectiveScale()
    left,top=left*ratio,top*ratio-UIParent:GetHeight()
    local screen=self:PanelAreaAt(left,top,f:GetWidth()*ratio,f:GetHeight()*ratio)
    if not screen then return false end
    local x,y,w,h=self:Area(screen)
    self.db.positions[positionKey(name,f)]={screen=screen,x=(left-x)/w,y=(top-y)/h}
    return true
end
function app:FinishPanelDrag(name)
    local f=self.panels[name]
    if not f or not f.fdsDragging then return end
    self:Safe("mémoriser:"..name,function()
        self:SavePanelPosition(name)
        f.fdsDragging=nil
        self:PlacePanel(name)
    end)
end
function app:SetAllPanels(value)
    for _,item in ipairs(self.panelCatalog) do self.db.panels[item[2]]=value and true or false end
    self:Apply(); self:RefreshOptions()
end
-- Coalesce native anchor/size updates into one pass after Blizzard's layout.
function app:QueuePanel(name)
    local f=self.panels[name]
    if not f or f.IsForbidden and f:IsForbidden() or f.fdsPlacing or f.fdsDragging or self.panelRestore or not self.db or not wanted(name) then return end
    self.panelQueued=self.panelQueued or {}
    if self.panelQueued[name] then return end
    self.panelQueued[name]=true
    C_Timer.After(0,function()
        -- Keep the guard set while placing (including synchronous test timers).
        if app.db.enabled and f:IsShown() and not f.fdsDragging and app:Bridge() then app:PlacePanel(name) end
        app.panelQueued[name]=nil
    end)
end
function app:PlacePanel(name)
    local f=self.panels[name]
    if not f or f.IsForbidden and f:IsForbidden() or f.fdsDragging or not self.db.enabled or not wanted(name) then return end
    self:Safe("panneau:"..name,function()
        if f.fdsDragging or not self.db.enabled or not wanted(name) then return end
        local p=self.db.positions[positionKey(name,f)] or self.db.positions[name]
        local screen=p and p.screen=="game" and "game" or "workspace"
        local x,y,w,h=self:Area(screen)
        if not x then return end
        if name=="WorldMapFrame" then self:SyncWorkspaceMap(true) end
        if f.IsMaximized and f:IsMaximized() then self:Record("Carte agrandie : repasse en mode fenêtre pour la déplacer."); return end
        if f:IsShown() and self.RememberWorkspaceVisible then self:RememberWorkspaceVisible(name,f) end
        self:Remember(f)
        local scale=self.db.scales[name] or (name:match("^ContainerFrame%d+$") and self.db.scales.ContainerFrameCombinedBags) or 1
        f.fdsPlacing=true
        f:SetScale(scale)
        local ratio=UIParent:GetEffectiveScale()/f:GetEffectiveScale()
        if self.db.autoFit then
            local fit=math.min(1,(w-32)/math.max(1,f:GetWidth()/ratio),(h-64)/math.max(1,f:GetHeight()/ratio))
            if fit<1 then f:SetScale(math.max(0.25,scale*fit)); ratio=UIParent:GetEffectiveScale()/f:GetEffectiveScale() end
        end
        local index=tonumber(name:match("^ContainerFrame(%d+)$")) or 1
        local ox,oy=20+(index-1)%3*48, -42-math.floor((index-1)/3)*42
        if name=="ContainerFrameCombinedBags" then ox=math.max(20,w-f:GetWidth()/ratio-20) end
        if p then ox,oy=p.x*w,p.y*h end
        local fw,fh=f:GetWidth()/ratio,f:GetHeight()/ratio
        ox=math.max(0,math.min(ox,math.max(0,w-fw)))
        oy=math.min(0,math.max(oy,-math.max(0,h-fh)))
        f:ClearAllPoints()
        f:SetPoint("TOPLEFT",UIParent,"TOPLEFT",(x+ox)*ratio,(y+oy)*ratio)
        f.fdsPlacing=nil
    end)
    f.fdsPlacing=nil
end
function app:DiscoverPanels()
    if InCombatLockdown() then self.pending.decouverte=function() self:DiscoverPanels(); self:Apply() end; return end
    for _,name in ipairs(names) do
        local f=_G[name]
        if f and not self.panels[name] and not (f.IsForbidden and f:IsForbidden()) then
            self.panels[name]=f; f.fdsPanel=true
            f:HookScript("OnShow",function()
                -- Let Blizzard finish its native initial positioning first.
                app:QueuePanel(name)
            end)
            f:HookScript("OnSizeChanged",function() app:QueuePanel(name) end)
            if hooksecurefunc then
                hooksecurefunc(f,"SetPoint",function() app:QueuePanel(name) end)
                hooksecurefunc(f,"SetScale",function() app:QueuePanel(name) end)
                hooksecurefunc(f,"StartMoving",function()
                    if app.db.enabled and wanted(name) and app:Bridge() then f.fdsDragging=true end
                end)
                hooksecurefunc(f,"StopMovingOrSizing",function()
                    C_Timer.After(0,function() app:FinishPanelDrag(name) end)
                end)
            end
            -- A separate handle avoids replacing native panel mouse handlers.
            local grip=CreateFrame("Button",nil,f,"BackdropTemplate")
            grip:SetSize(130,18); grip:SetPoint("BOTTOMLEFT",f,"TOPLEFT",8,0)
            grip:SetNormalFontObject("GameFontNormalSmall"); grip:SetText("Déplacer : maintenir")
            grip:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
            grip:SetBackdropColor(0.04,0.12,0.18,0.95)
            grip:RegisterForDrag("LeftButton")
            grip:SetScript("OnDragStart",function()
                if InCombatLockdown() or not app.db.enabled or not wanted(name) or not app:Bridge() then return end
                app:Remember(f); f:SetMovable(true); f.fdsDragging=true; f:StartMoving(); grip.moving=true
            end)
            grip:SetScript("OnDragStop",function()
                if not grip.moving then return end
                grip.moving=false
                if InCombatLockdown() then
                    app.pending["arreter:"..name]=function() f:StopMovingOrSizing(); app:FinishPanelDrag(name) end
                    return
                end
                f:StopMovingOrSizing()
                app:FinishPanelDrag(name)
            end)
            self.panels[name..":grip"]=grip
        end
    end
    -- Native bag opening can re-anchor already visible combined/reagent bags.
    if hooksecurefunc and not self.bagAnchorsHooked and type(UpdateContainerFrameAnchors)=="function" then
        self.bagAnchorsHooked=true
        hooksecurefunc("UpdateContainerFrameAnchors",function()
            for _,name in ipairs(names) do
                if name:match("^ContainerFrame") then app:QueuePanel(name) end
            end
        end)
    end
end
function app:ApplyPanels()
    self:DiscoverPanels()
    if self.InitWorkspaceVisibility then self:InitWorkspaceVisibility() end
    self:SyncWorkspaceMap(self.db.enabled and self.db.panels.WorldMapFrame and self.viewportActive)
    for _,name in ipairs(names) do
        local f=self.panels[name]
        if f and not (f.IsForbidden and f:IsForbidden()) then
            if self.WatchWorkspacePanel then self:WatchWorkspacePanel(name,f) end
            local grip=self.panels[name..":grip"]
            grip:SetShown(self.db.enabled and wanted(name))
            if wanted(name) and f:IsShown() then self:PlacePanel(name)
            elseif not wanted(name) then self:RestoreFrame(f) end
        end
    end
end
function app:Recover()
    self:Safe("récupération",function()
        local x,y,w,h=self:Area("game")
        if not x then x,y,w,h=0,0,UIParent:GetWidth(),UIParent:GetHeight() end
        self.panelRestore=true
        for _,name in ipairs(names) do
            local f=self.panels[name]
            if f and not (f.IsForbidden and f:IsForbidden()) and f:IsShown() then
                self:Remember(f)
                local ratio=UIParent:GetEffectiveScale()/f:GetEffectiveScale()
                if wanted(name) and self:Bridge() then
                    self.db.positions[positionKey(name,f)]={screen="game",x=25/w,y=-45/h}
                    self:PlacePanel(name)
                else
                    f:ClearAllPoints(); f:SetPoint("TOPLEFT",UIParent,"TOPLEFT",(x+25)*ratio,(y-45)*ratio)
                end
            end
        end
        self.panelRestore=nil
    end)
    self.panelRestore=nil
end
function app:ShowWorkspaceMap()
    if InCombatLockdown() then self:Message("Attends la fin du combat pour déplacer la carte."); return end
    if not WorldMapFrame then
        local load=C_AddOns and C_AddOns.LoadAddOn or LoadAddOn
        if load then load("Blizzard_WorldMap") end
    end
    local map=WorldMapFrame
    if not map then self:Message("La carte n’est pas disponible. Ouvre-la avec la touche habituelle."); return end
    self.db.panels.WorldMapFrame=true
    if not map:IsShown() then
        if ToggleWorldMap then ToggleWorldMap() else map:Show() end
    end
    if map.IsMaximized and map:IsMaximized() then
        local action=map.HandleUserActionMinimizeSelf or map.Minimize
        if type(action)=="function" then action(map)
        else
            local controls=map.MaximizeMinimizeFrame
            if controls and type(controls.Minimize)=="function" then controls:Minimize()
            else self:Message("Utilise le bouton de la carte pour passer en mode fenêtré."); return end
        end
    end
    self:DiscoverPanels()
    C_Timer.After(0,function() self:PlacePanel("WorldMapFrame"); self:RefreshOptions() end)
end
