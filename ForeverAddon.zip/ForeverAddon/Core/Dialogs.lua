local _,app=...
-- Native dialogs stay on the game monitor; never detach their buttons, change
-- handlers or add them to the draggable workspace panel catalog.
local names={"GameMenuFrame","SettingsPanel","InterfaceOptionsFrame","VideoOptionsFrame","AudioOptionsFrame","KeyBindingFrame","StaticPopup1","StaticPopup2","StaticPopup3","StaticPopup4","LFGListInviteDialog","LFGDungeonReadyDialog","PVPReadyDialog","ReadyCheckFrame","GroupInviteFrame","ResurrectFrame"}
local centered={GameMenuFrame=true,SettingsPanel=true,InterfaceOptionsFrame=true,VideoOptionsFrame=true,AudioOptionsFrame=true,KeyBindingFrame=true}
local anchors={TOPLEFT={0,0},TOP={0.5,0},TOPRIGHT={1,0},LEFT={0,0.5},CENTER={0.5,0.5},RIGHT={1,0.5},BOTTOMLEFT={0,1},BOTTOM={0.5,1},BOTTOMRIGHT={1,1}}
local states={}
local function points(f) local p={};for i=1,f:GetNumPoints() do p[i]={f:GetPoint(i)} end;return p end
local function forbidden(f) return f.IsForbidden and f:IsForbidden() end
function app:PlaceNativeDialog(f)
    local state=states[f];if not state or state.busy or forbidden(f) then return end
    self:Safe("dialogue Blizzard:"..state.name,function()
        if not self.db.enabled or not self.viewportActive then return end
        local x,y,w,h=self:Area("game");if not x then return end
        local source=state.source or points(f)
        if #source==0 then return end
        -- Chained dialogs follow their native predecessor. Do not break that chain.
        for _,p in ipairs(source) do
            if (p[2]~=nil and p[2]~=UIParent and p[2]~="UIParent") or not anchors[p[3]] then return end
        end
        state.source=source
        local ratio=UIParent:GetEffectiveScale()/f:GetEffectiveScale()
        state.busy=true
        local ok,err=pcall(function()
            f:ClearAllPoints()
            if centered[state.name] then
                f:SetPoint("CENTER",UIParent,"TOPLEFT",(x+w/2)*ratio,(y-h/2)*ratio)
            else
                for _,p in ipairs(source) do
                    local pivot=anchors[p[3]]
                    f:SetPoint(p[1],UIParent,p[3],(p[4] or 0)+(x+pivot[1]*(w-UIParent:GetWidth()))*ratio,(p[5] or 0)+(y-pivot[2]*(h-UIParent:GetHeight()))*ratio)
                end
            end
        end)
        state.busy=false
        if not ok then error(err) end
        state.moved=true
    end)
end
function app:QueueNativeDialog(f)
    local state=states[f]
    if not state or state.busy or state.queued or forbidden(f) then return end
    state.queued=true
    C_Timer.After(0,function()
        -- Native show/positioning has completed before any addon mutation.
        app:PlaceNativeDialog(f);state.queued=false
    end)
end
function app:ReleaseNativeDialogs()
    for f,state in pairs(states) do
        if state.moved and state.source and not forbidden(f) then
            self:Safe("restaurer dialogue:"..state.name,function()
                state.busy=true
                local ok,err=pcall(function()
                    f:ClearAllPoints();for _,p in ipairs(state.source) do f:SetPoint(unpack(p,1,5)) end
                end)
                state.busy=false
                if not ok then error(err) end
                state.moved=false
            end)
        end
    end
end
function app:ApplyNativeDialogs()
    for _,name in ipairs(names) do
        local f=_G[name]
        if f and not states[f] and not forbidden(f) then
            local state={name=name};states[f]=state
            f:HookScript("OnShow",function() app:QueueNativeDialog(f) end)
            if hooksecurefunc then hooksecurefunc(f,"SetPoint",function()
                if state.busy or forbidden(f) then return end
                local ok,p=pcall(points,f);if ok then state.source=p;state.moved=false end
                app:QueueNativeDialog(f)
            end) end
        end
        if f and states[f] then self:PlaceNativeDialog(f) end
    end
end
-- Keep the Blizzard warning intact. Record its actual function for /fds diag.
local events=CreateFrame("Frame")
events:RegisterEvent("ADDON_ACTION_BLOCKED");events:RegisterEvent("ADDON_ACTION_FORBIDDEN")
events:SetScript("OnEvent",function(_,event,addon,action)
    if not app.db or type(addon)~="string" or not addon:lower():find("foreveraddon",1,true) then return end
    local data={version=app.version,event=event,action=tostring(action):sub(1,240),time=date("%H:%M:%S"),operation=app.currentOperation}
    app.db.lastBlockedAction=data
    app:Record(event.." : "..data.action.." | "..tostring(data.operation or "appel natif"))
    if app.lastBlockedNotice~=data.action then
        app.lastBlockedNotice=data.action
        app:Message("Action refusée par Blizzard : "..data.action..". /fds diag conserve le détail.")
    end
end)
