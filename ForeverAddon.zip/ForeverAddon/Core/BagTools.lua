local _,app=...
local state={selected={},overlays={},mode=false}
app.bagTools=state
local function options() return app.db and app.db.modules or {} end
local function maxBag() return NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4 end
local function heldBag(bag) return type(bag)=="number" and not (issecretvalue and issecretvalue(bag)) and bag>=0 and bag<=maxBag() end
local function forbidden(f) return f and f.IsForbidden and f:IsForbidden() end
local function key(bag,slot) return bag..":"..slot end
local function secret(v) return issecretvalue and issecretvalue(v) end
local function snapshot(bag,slot)
    if not heldBag(bag) or type(slot)~="number" or slot<1 then return nil end
    local info
    if C_Container and C_Container.GetContainerItemInfo then
        local ok,value=pcall(C_Container.GetContainerItemInfo,bag,slot);if ok then info=value end
    elseif GetContainerItemInfo then
        local ok,icon,count,locked,quality,readable,lootable,link,filtered,noValue,id=pcall(GetContainerItemInfo,bag,slot)
        if ok and icon then info={stackCount=count,isLocked=locked,hyperlink=link,itemID=id} end
    end
    if type(info)~="table" or secret(info.itemID) or secret(info.stackCount) or secret(info.hyperlink) or secret(info.isLocked) then return nil end
    local id=info.itemID or (info.hyperlink and tonumber(info.hyperlink:match("item:(%d+)")))
    if not id then return nil end
    local guid
    if C_Item and C_Item.GetItemGUID and ItemLocation and ItemLocation.CreateFromBagAndSlot then
        local ok,value=pcall(function() return C_Item.GetItemGUID(ItemLocation:CreateFromBagAndSlot(bag,slot)) end)
        if ok and not secret(value) then guid=value end
    end
    return {bag=bag,slot=slot,id=id,link=info.hyperlink,count=info.stackCount or 1,locked=info.isLocked,guid=guid,key=key(bag,slot)}
end
local function same(a,b)
    return a and b and a.id==b.id and a.link==b.link and a.count==b.count and (not a.guid or a.guid==b.guid)
end
local function cursor()
    if not GetCursorInfo then return nil end
    local kind,id,link=GetCursorInfo()
    if kind~="item" or secret(id) or secret(link) then return nil end
    local guid
    if C_Cursor and C_Cursor.GetCursorItem and C_Item and C_Item.GetItemGUID then
        local ok,value=pcall(function()
            local location=C_Cursor.GetCursorItem()
            return location and C_Item.GetItemGUID(location)
        end)
        if ok and not secret(value) then guid=value end
    end
    return {id=id,link=link,guid=guid}
end
local function itemPayload(link)
    if type(link)~="string" then return nil end
    return link:match("|H(item:[^|]+)|h") or link:match("^(item:[^|]+)$")
end
local function cursorMatches(item)
    local c=cursor()
    if not c or c.id~=item.id then return false end
    if item.guid and c.guid then return item.guid==c.guid end
    if not item.link then return true end
    if c.link==item.link then return true end
    local a,b=itemPayload(item.link),itemPayload(c.link)
    return a~=nil and b~=nil and a==b
end
local function countSelected() local n=0;for _ in pairs(state.selected) do n=n+1 end;return n end
local function allowed()
    if InCombatLockdown() then app:Message("Gestion des sacs suspendue pendant le combat.");return false end
    if state.blocked then app:Message("Blizzard a refusé cette action. Consulte /fds diag puis recharge l'interface.");return false end
    if type(DeleteCursorItem)~="function" then app:Message("Ce client ne propose pas la destruction au curseur.");return false end
    return true
end
local function label(parent,text,x,y,width)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    t:SetPoint("TOPLEFT",x,y);t:SetWidth(width);t:SetJustifyH("LEFT");t:SetText(text);return t
end
local function button(parent,text,x,y,w,action)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",x,y);b:SetSize(w,26);b:SetText(text);b:SetScript("OnClick",action);return b
end
function app:QueueBagTools()
    if state.syncQueued or not state.initialized then return end
    state.syncQueued=true
    C_Timer.After(0,function() state.syncQueued=false;app:SyncBagTools() end)
end
function app:CancelBagTools(returnCursor)
    if returnCursor and state.current and cursorMatches(state.current) and ClearCursor then ClearCursor() end
    state.current=nil;state.queue=nil;state.selected={};state.mode=false;state.waiting=false;state.prepared=false;state.settleChecks=0
    self:QueueBagTools()
end
function app:SetBagToolOption(name,value)
    self.db.modules=self.db.modules or {};self.db.modules[name]=value and true or false
    self:CancelBagTools(false);self:SyncBagTools();self:RefreshOptions()
end
function app:SelectBagToolSlot(bag,slot)
    if not options().bagMulti or not state.mode or state.current or not allowed() then return end
    if GetCursorInfo and GetCursorInfo() then self:Message("Repose d'abord l'objet tenu par le curseur.");return end
    local item=snapshot(bag,slot)
    if not item or item.locked then self:Message("Cet emplacement est vide, verrouillé ou indisponible.");return end
    if state.selected[item.key] then state.selected[item.key]=nil else state.selected[item.key]=item end
    self:SyncBagTools()
end
function app:StartBagToolSelection()
    if not options().bagMulti or not allowed() then return end
    if state.mode then
        if countSelected()>0 then
            self:ReviewBagToolSelection()
            -- The same hardware click validates the selection and requests its
            -- first pile. Following piles still require their own user click.
            self:DeleteBagToolCurrent()
        else self:Message("Sélectionne les piles à détruire, ou clique Annuler.") end
        return
    end
    if not RegisterStateDriver then self:Message("La sélection nécessite la gestion native de visibilité en combat.");return end
    if GetCursorInfo and GetCursorInfo() then self:Message("Repose d'abord l'objet tenu par le curseur.");return end
    state.mode=true;state.selected={};self:SyncBagTools()
end
function app:ReviewBagToolSelection()
    if not options().bagMulti or not state.mode or not allowed() or state.waiting then return end
    if state.current then return end
    local queue={}
    for _,item in pairs(state.selected) do
        local now=snapshot(item.bag,item.slot)
        if not same(item,now) or now.locked then self:CancelBagTools(false);self:Message("Le contenu des sacs a changé. Refais la sélection.");return end
        queue[#queue+1]=item
    end
    if #queue==0 then return end
    table.sort(queue,function(a,b) if a.bag==b.bag then return a.slot<b.slot end;return a.bag<b.bag end)
    state.total=#queue;state.completed=0
    state.queue=queue;state.current=queue[1];state.waiting=false;state.prepared=false;state.settleChecks=0;self:SyncBagTools()
end
-- Both callers are direct hardware handlers: OnClick or OnReceiveDrag.
function app:DeleteBagToolCursor()
    if not options().bagTrash or not allowed() or state.waiting then return end
    local item=cursor()
    if not item then self:Message("Dépose une pile sur la poubelle pour demander sa destruction.");return end
    self:CancelBagTools(false);item.fromCursor=true;state.current=item
    self:DeleteBagToolCurrent()
end
-- One request from a hardware handler; never queued or looped.
function app:DeleteBagToolCurrent()
    local item=state.current
    if not item or state.waiting or not allowed() then return end
    if item.fromCursor then
        if not options().bagTrash or not cursorMatches(item) then self:CancelBagTools(false);return end
    else
        if not options().bagMulti then self:CancelBagTools(false);return end
        if not state.prepared then
            if GetCursorInfo and GetCursorInfo() then self:Message("Repose l'objet tenu avant de continuer.");return end
            local now=snapshot(item.bag,item.slot)
            if not same(item,now) or now.locked then self:CancelBagTools(false);self:Message("La pile a changé. Aucune destruction demandée.");return end
            local pickup=C_Container and C_Container.PickupContainerItem or PickupContainerItem
            if not pickup then self:Message("Déplacement de pile indisponible sur ce client.");return end
            state.prepared=true
            local ok=pcall(pickup,item.bag,item.slot)
            if not ok then self:CancelBagTools(false);self:Message("La pile n'a pas été prise en charge. Aucune destruction demandée.");return end
        end
        if not cursorMatches(item) then
            self:Message("Pile au curseur non vérifiée. Attends sa mise à jour puis reclique, ou annule. Aucun objet détruit.")
            self:QueueBagTools();return
        end
    end
    state.waiting=true;state.settleChecks=0
    local ok,err=pcall(DeleteCursorItem) -- exactly one request; native confirmation is untouched
    if not ok then state.blocked=true;self:Record("Poubelle : "..tostring(err)) end
    self:QueueBagTools()
end
function app:ObserveBagTools()
    local item=state.current
    if item and state.prepared and not state.waiting and not (GetCursorInfo and GetCursorInfo()) then
        local now=snapshot(item.bag,item.slot)
        if same(item,now) and not now.locked then state.prepared=false end
    end
    if item and state.waiting then
        if cursor() then
            if not cursorMatches(item) then self:CancelBagTools(false) end
            return
        end
        if item.fromCursor then self:CancelBagTools(false);return end
        local now=snapshot(item.bag,item.slot)
        if same(item,now) then
            -- CURSOR_CHANGED is synchronous; the bag cache may still show the
            -- deleted pile. Observe only: never pick up or delete from a timer.
            if (state.settleChecks or 0)<10 then
                if not state.settleQueued then
                    state.settleChecks=(state.settleChecks or 0)+1;state.settleQueued=true
                    C_Timer.After(0.15,function()
                        state.settleQueued=false
                        if state.current==item and state.waiting then app:ObserveBagTools();app:QueueBagTools() end
                    end)
                end
                return
            end
            self:CancelBagTools(false);return -- native cancellation or unchanged source
        end
        if now then self:CancelBagTools(false);self:Message("L'emplacement a changé : sélection annulée.");return end
        state.completed=(state.completed or 0)+1
        state.selected[item.key]=nil
        if state.queue then table.remove(state.queue,1) end
        state.current=state.queue and state.queue[1];state.waiting=false;state.prepared=false;state.settleChecks=0
        if not state.current then
            self:Message("Sélection terminée : "..(state.completed or 0).." pile(s) détruite(s).")
            self:CancelBagTools(false);return
        end
        -- Only display the next pile. Its pickup/deletion still needs another click.
    end
    if state.mode then
        for _,selected in pairs(state.selected) do
            if not (state.prepared and selected==state.current) and not same(selected,snapshot(selected.bag,selected.slot)) then
                self:CancelBagTools(false);self:Message("Les sacs ont changé : sélection annulée.");return
            end
        end
    end
end
local function tooltip(b,text)
    b:SetScript("OnEnter",function()
        if GameTooltip and not forbidden(GameTooltip) then GameTooltip:SetOwner(b,"ANCHOR_RIGHT");GameTooltip:SetText(text);GameTooltip:Show() end
    end)
    b:SetScript("OnLeave",function() if GameTooltip and not forbidden(GameTooltip) then GameTooltip:Hide() end end)
end
-- Our windows keep monitor-relative coordinates, like the managed panels.
function app:SaveBagToolWindow(frame,name)
    local left,top=frame:GetLeft(),frame:GetTop()
    if not left or not top then return end
    local ratio=frame:GetEffectiveScale()/UIParent:GetEffectiveScale()
    left,top=left*ratio,top*ratio-UIParent:GetHeight()
    local screen=self:PanelAreaAt(left,top,frame:GetWidth()*ratio,frame:GetHeight()*ratio)
    local x,y,w,h=self:Area(screen or "game")
    if not x then screen="canvas";x,y,w,h=0,0,UIParent:GetWidth(),UIParent:GetHeight() end
    self.db.positions[name]={screen=screen,x=(left-x)/w,y=(top-y)/h}
end
function app:PlaceBagToolWindow(frame,name)
    local p=self.db.positions[name]
    if not p or type(p.x)~="number" or type(p.y)~="number" then return false end
    local screen=p.screen=="workspace" and "workspace" or "game"
    local x,y,w,h
    if p.screen~="canvas" then x,y,w,h=self:Area(screen) end
    if not x then x,y,w,h=0,0,UIParent:GetWidth(),UIParent:GetHeight() end
    local ratio=frame:GetEffectiveScale()/UIParent:GetEffectiveScale()
    local left=x+math.max(0,math.min(w-frame:GetWidth()*ratio,p.x*w))
    local top=y+math.max(math.min(0,frame:GetHeight()*ratio-h),math.min(0,p.y*h))
    frame:ClearAllPoints();frame:SetPoint("TOPLEFT",UIParent,"TOPLEFT",left/ratio,top/ratio)
    return true
end
local function movable(frame,name)
    frame:SetMovable(true);frame:EnableMouse(true);frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart",function()
        if InCombatLockdown() then return end
        frame.fdsBagDragging=true;frame:StartMoving()
    end)
    local function finish()
        if not frame.fdsBagDragging then return end
        app:Safe("déplacement poubelle:"..name,function()
            frame:StopMovingOrSizing();app:SaveBagToolWindow(frame,name)
            frame.fdsBagDragging=nil;app:QueueBagTools()
        end)
    end
    frame:SetScript("OnDragStop",finish)
    frame:HookScript("OnHide",finish)
end
local function trashIcon(parent)
    local icon=CreateFrame("Frame",nil,parent);icon:SetSize(20,22)
    local function rect(w,h,x,y,r,g,b)
        local t=icon:CreateTexture(nil,"OVERLAY");t:SetColorTexture(r,g,b,1);t:SetSize(w,h);t:SetPoint("CENTER",icon,"CENTER",x,y)
    end
    rect(12,12,0,-2,0.8,0.8,0.8);rect(8,9,0,-1,0.16,0.16,0.16)
    rect(16,2,0,6,0.85,0.85,0.85);rect(6,2,0,9,0.85,0.85,0.85)
    return icon
end
function app:InitBagTools(bag)
    if state.initialized then return end
    state.initialized=true;state.bag=bag
    local bar=CreateFrame("Frame",nil,bag);bar:SetSize(136,26);bar:SetPoint("TOPRIGHT",bag,"TOPRIGHT",-42,-34);state.bar=bar
    local trash=button(bar,"",0,0,28,function() app:DeleteBagToolCursor() end);state.trash=trash
    trashIcon(trash):SetPoint("CENTER",trash,"CENTER",0,0)
    tooltip(trash,"Poubelle : dépose une pile ou clique avec une pile au curseur. Demande directement sa destruction, avec les confirmations Blizzard habituelles.")
    trash:SetScript("OnReceiveDrag",function() app:DeleteBagToolCursor() end)
    state.select=button(bar,"Sélection",34,0,128,function() app:StartBagToolSelection() end)
    state.selectIcon=trashIcon(state.select);state.selectIcon:SetPoint("LEFT",state.select,"LEFT",5,0)
    tooltip(state.select,"Clique pour sélectionner des piles. Le bouton devient une poubelle : reclique pour demander la destruction de la première pile. Le même bouton traite ensuite chaque pile suivante, avec les confirmations Blizzard.")
    local tray=CreateFrame("Frame",nil,UIParent,"BackdropTemplate");tray:SetSize(144,48);tray:SetFrameStrata("DIALOG");tray:SetClampedToScreen(true);state.tray=tray
    label(tray,"Déplacer : maintenir",2,-2,140):SetFontObject("GameFontHighlightSmall")
    button(tray,"Annuler",0,-20,144,function() app:CancelBagTools(true) end)
    movable(tray,"FDSBagToolsTray")
    local review=CreateFrame("Frame","FDSBagToolsReview",UIParent,"BackdropTemplate")
    review:SetSize(510,242);review:SetFrameStrata("DIALOG");review:SetClampedToScreen(true)
    review:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\DialogFrame\\UI-DialogBox-Border",edgeSize=22})
    review:SetBackdropColor(0.035,0.04,0.05,1);review:Hide();state.review=review
    label(review,"Destruction de la sélection — déplacer : maintenir",22,-22,466)
    movable(review,"FDSBagToolsReview")
    state.reviewItem=label(review,"",22,-57,466)
    local progress=CreateFrame("StatusBar",nil,review);progress:SetPoint("TOPLEFT",22,-98);progress:SetSize(466,16)
    progress:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar");progress:SetStatusBarColor(0.1,0.65,0.3)
    local track=progress:CreateTexture(nil,"BACKGROUND");track:SetAllPoints(progress);track:SetColorTexture(0.12,0.12,0.12,1)
    state.progress=progress;state.progressText=progress:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    state.progressText:SetPoint("CENTER",progress,"CENTER",0,0)
    state.reviewNotice=label(review,"",22,-127,466)
    state.confirm=button(review,"Détruire la pile suivante",22,-195,225,function() app:DeleteBagToolCurrent() end)
    button(review,"Annuler",263,-195,225,function() app:CancelBagTools(true) end)
    review:HookScript("OnHide",function() if not state.syncing then app:CancelBagTools(false) end end)
    table.insert(UISpecialFrames,"FDSBagToolsReview")
    bag:HookScript("OnShow",function() app:QueueBagTools() end)
    bag:HookScript("OnHide",function() app:CancelBagTools(false) end)
    if hooksecurefunc then
        for _,method in ipairs({"UpdateItemLayout","UpdateFrameSize","SetSearchBoxPoint","SetPoint","SetScale"}) do
            if type(bag[method])=="function" then hooksecurefunc(bag,method,function()
                if not state.syncing then
                    if method=="SetSearchBoxPoint" and BagItemSearchBox then state.searchWidth=BagItemSearchBox:GetWidth() end
                    app:QueueBagTools()
                end
            end) end
        end
    end
    local events=CreateFrame("Frame");state.events=events
    for _,e in ipairs({"BAG_UPDATE_DELAYED","CURSOR_CHANGED","ITEM_LOCK_CHANGED","PLAYER_REGEN_DISABLED","PLAYER_REGEN_ENABLED","PLAYER_LEAVING_WORLD","ADDON_ACTION_BLOCKED","ADDON_ACTION_FORBIDDEN"}) do events:RegisterEvent(e) end
    events:SetScript("OnEvent",function(_,e,addon,action)
        if e=="PLAYER_LEAVING_WORLD" then app:CancelBagTools(false)
        elseif e=="PLAYER_REGEN_DISABLED" then state.current=nil;state.queue=nil;state.selected={};state.mode=false;state.prepared=false
        elseif (e=="ADDON_ACTION_BLOCKED" or e=="ADDON_ACTION_FORBIDDEN") and addon==app.name and tostring(action):find("DeleteCursorItem",1,true) then state.blocked=true end
        if e~="PLAYER_REGEN_DISABLED" and not state.observeQueued then
            if not options().bagTrash and not options().bagMulti and not state.current then return end
            state.observeQueued=true
            C_Timer.After(0,function()
                state.observeQueued=false;app:ObserveBagTools();app:QueueBagTools()
            end)
        end
    end)
end
function app:SyncBagTools()
    local opts=options();local enabled=opts.bagTrash or opts.bagMulti
    if not enabled and not state.initialized then return end
    local bag=ContainerFrameCombinedBags
    if not bag or forbidden(bag) or state.syncing then return end
    if InCombatLockdown() then self.pending["modules sacs"]=function() self:SyncBagTools() end;return end
    self:Safe("modules sacs",function()
        self:InitBagTools(bag);state.syncing=true
        local ok,err=pcall(function()
            if not enabled then state.mode=false;state.current=nil;state.queue=nil;state.selected={} end
            local visible=enabled and bag:IsShown()
            state.bar:SetShown(visible);state.trash:SetShown(opts.bagTrash and visible)
            state.select:SetShown(opts.bagMulti and visible)
            state.select:ClearAllPoints();state.select:SetPoint("TOPLEFT",state.bar,"TOPLEFT",opts.bagTrash and 34 or 0,0)
            state.bar:SetWidth((opts.bagTrash and 34 or 0)+(opts.bagMulti and 128 or 0))
            state.select:SetText(state.mode and ("    Détruire ("..countSelected()..")") or "Sélection")
            state.selectIcon:SetShown(state.mode)
            state.select:SetEnabled(not state.waiting and not state.blocked)
            local search=BagItemSearchBox
            if search and search:GetParent()==bag then
                state.searchWidth=state.searchWidth or search:GetWidth()
                local available=bag:GetWidth()-62-42-state.bar:GetWidth()-8
                search:SetWidth(enabled and math.min(state.searchWidth,math.max(60,available)) or state.searchWidth)
            end
            if opts.bagMulti and not state.layer and RegisterStateDriver then
                local layer=CreateFrame("Frame",nil,UIParent,"SecureHandlerStateTemplate");layer:SetAllPoints(UIParent);layer:SetFrameStrata("DIALOG")
                RegisterStateDriver(layer,"visibility","[combat] hide; show");state.layer=layer
            end
            for _,overlay in pairs(state.overlays) do overlay:Hide() end
            if state.layer and opts.bagMulti and state.mode and visible then
                for _,itemButton in ipairs(bag.Items or {}) do
                    if not forbidden(itemButton) and itemButton:IsShown() and itemButton.GetBagID and itemButton.GetID then
                        local bagID,slot=itemButton:GetBagID(),itemButton:GetID()
                        if heldBag(bagID) and snapshot(bagID,slot) then
                            local overlay=state.overlays[itemButton]
                            if not overlay then
                                overlay=CreateFrame("Button",nil,state.layer,"BackdropTemplate");state.overlays[itemButton]=overlay
                                overlay:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=2})
                                overlay:SetScript("OnClick",function() app:SelectBagToolSlot(overlay.bag,overlay.slot) end)
                                overlay:SetScript("OnEnter",function() if GameTooltip and GameTooltip.SetBagItem and not forbidden(GameTooltip) then GameTooltip:SetOwner(overlay,"ANCHOR_RIGHT");GameTooltip:SetBagItem(overlay.bag,overlay.slot);GameTooltip:Show() end end)
                                overlay:SetScript("OnLeave",function() if GameTooltip and not forbidden(GameTooltip) then GameTooltip:Hide() end end)
                            end
                            local l,b,w,h=itemButton:GetRect();local ratio=itemButton:GetEffectiveScale()/UIParent:GetEffectiveScale()
                            if l and w and h then
                                overlay.bag,overlay.slot=bagID,slot;overlay:ClearAllPoints();overlay:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",l*ratio,(b+h)*ratio);overlay:SetSize(w*ratio,h*ratio)
                                local selected=state.selected[key(bagID,slot)]
                                overlay:SetBackdropColor(0.6,0,0,selected and 0.18 or 0)
                                overlay:SetBackdropBorderColor(1,0.08,0.04,selected and 1 or 0.12);overlay:Show()
                            end
                        end
                    end
                end
            end
            
            local l,b,w,h=bag:GetRect();l,b,w,h=l or 0,b or 0,w or bag:GetWidth(),h or bag:GetHeight();local ratio=bag:GetEffectiveScale()/UIParent:GetEffectiveScale()
            local x,y,aw,ah=self:Area(self:PanelAreaAt(l*ratio,(b+h)*ratio-UIParent:GetHeight(),w*ratio,h*ratio) or "game")
            if not x then x,y,aw,ah=0,0,UIParent:GetWidth(),UIParent:GetHeight() end
            local top=(b+h)*ratio+52;local monitorTop=UIParent:GetHeight()+y
            if top>monitorTop then top=math.max(monitorTop-ah+48,b*ratio-4) end
            if not state.tray.fdsBagDragging and not self:PlaceBagToolWindow(state.tray,"FDSBagToolsTray") then
                state.tray:ClearAllPoints();state.tray:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",math.max(x,math.min((l+w)*ratio-144,x+aw-144)),top)
            end
            state.tray:SetShown(visible and opts.bagMulti and state.mode)
            local item=state.current
            if not state.review.fdsBagDragging then
                local gx,gy,gw,gh=self:Area("game")
                state.review:SetScale(math.max(0.2,math.min(1,((gw or UIParent:GetWidth())-24)/510,((gh or UIParent:GetHeight())-24)/242)))
                local reviewRatio=UIParent:GetEffectiveScale()/state.review:GetEffectiveScale()
                if not self:PlaceBagToolWindow(state.review,"FDSBagToolsReview") then
                    state.review:ClearAllPoints()
                    if gx then state.review:SetPoint("CENTER",UIParent,"TOPLEFT",(gx+gw/2)*reviewRatio,(gy-gh/2)*reviewRatio) else state.review:SetPoint("CENTER",UIParent,"CENTER",0,0) end
                end
            end
            local total=state.total or 1;local completed=state.completed or 0
            state.progress:SetMinMaxValues(0,math.max(1,total));state.progress:SetValue(completed)
            state.progressText:SetText(completed.." / "..total.." pile(s) détruite(s)")
            state.reviewItem:SetText(item and ((item.link or ("Objet "..item.id)).."\nPile complète"..(item.count and (" : "..item.count.." objet(s)") or "")) or "")
            local notice
            if state.blocked then notice="Action refusée par le client. Consulte /fds diag."
            elseif state.waiting then
                notice=(GetCursorInfo and GetCursorInfo()) and "Valide ou annule la confirmation Blizzard.\nAucune pile suivante n'est traitée automatiquement." or "Synchronisation du contenu des sacs…\nLa pile suivante attendra ton clic."
            elseif state.prepared then notice="Vérifie la pile au curseur puis reclique pour continuer.\nAucune destruction n'est demandée automatiquement."
            else notice=(state.queue and (#state.queue.." pile(s) restante(s). ") or "").."Un clic par pile. Les confirmations Blizzard restent actives." end
            state.reviewNotice:SetText(notice)
            state.confirm:SetText(state.prepared and not state.waiting and "Continuer cette pile" or "Détruire la pile suivante")
            state.confirm:SetEnabled(item~=nil and not state.waiting and not state.blocked)
            state.review:SetShown(enabled and item~=nil and not item.fromCursor)
        end)
        state.syncing=false
        if not ok then error(err) end
    end)
end
