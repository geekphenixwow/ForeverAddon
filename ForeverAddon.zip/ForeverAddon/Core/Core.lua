local addonName, app = ...
app.name, app.version = addonName, "0.4.1"
app.pending, app.log = {}, {}
app.frames = {}
_G.ForeverAddon=app
function app:Message(text)
    DEFAULT_CHAT_FRAME:AddMessage("|cff4ed6ffForever Addon|r : " .. tostring(text))
end
function app:Record(text)
    if #self.log >= 40 then table.remove(self.log, 1) end
    self.log[#self.log+1] = date("%H:%M:%S") .. " " .. text
end
function app:Safe(key, action)
    if InCombatLockdown() then self.pending[key] = action; return false end
    local previous=self.currentOperation;self.currentOperation=key
    local ok, err = pcall(action)
    self.currentOperation=previous
    if not ok then
        local issue=key .. " : " .. tostring(err)
        self:Record(issue)
        if self.lastIssue~=issue then self:Message(issue) end
        self.lastIssue=issue
    end
    return ok
end
function app:Bridge()
    local incoming,decodeError=self:CompanionData()
    if decodeError and not self.db.manualBridge then return nil,decodeError end
    local candidate=self.db.manualBridge or incoming or self.db.cachedBridge
    local ok, reason = self.Geometry.Validate(candidate)
    if not ok then return nil, reason end
    local w, h = GetPhysicalScreenSize()
    local ready,state=self.Geometry.SurfaceState(candidate,w,h,UIParent:GetWidth(),UIParent:GetHeight())
    self.surfaceState=state
    if not ready then return nil,state end
    if incoming and not self.db.manualBridge then self.db.cachedBridge=incoming end
    return candidate
end
function app:Area(which)
    local b = self:Bridge()
    if not b then return nil end
    return self.Geometry.ToUI(b[which], b.canvas, UIParent:GetWidth(), UIParent:GetHeight())
end
function app:Remember(frame)
    if self.frames[frame] then return end
    local points = {}
    for i=1,frame:GetNumPoints() do points[i] = {frame:GetPoint(i)} end
    self.frames[frame] = {points=points, scale=frame:GetScale(), width=frame:GetWidth(), height=frame:GetHeight(), movable=frame:IsMovable()}
end
function app:RestoreFrame(frame)
    if frame.IsForbidden and frame:IsForbidden() then return end
    local state = self.frames[frame]
    if not state then return end
    local previous=self.panelRestore
    self.panelRestore=true
    local ok,err=pcall(function()
        frame:ClearAllPoints()
        for _,p in ipairs(state.points) do frame:SetPoint(unpack(p)) end
        frame:SetScale(state.scale)
        -- Panels resize their own content. We only changed their anchors/scale.
        if not frame.fdsPanel then frame:SetSize(state.width,state.height) end
        frame:SetMovable(state.movable)
    end)
    self.panelRestore=previous
    if not ok then error(err) end
end
function app:RestoreAll()
    self:Safe("restaurer", function()
        if self.ReleaseNativeDialogs then self:ReleaseNativeDialogs() end
        if self.ReleaseMicroTooltip then self:ReleaseMicroTooltip(true) end
        if self.ReleaseAncillaryHUD then self:ReleaseAncillaryHUD() end
        if self.RestoreNativeHUD then self:RestoreNativeHUD(false) end
        if self.SyncWorkspaceMap then self:SyncWorkspaceMap(false) end
        self:RestoreViewport()
        for frame in pairs(self.frames) do self:Safe("restaurer un cadre",function() self:RestoreFrame(frame) end) end
        if self.backdrop then self.backdrop:Hide() end
        if self.UpdateMinimapStatus then self:UpdateMinimapStatus() end
        if self.panels then
            for name, frame in pairs(self.panels) do if name:match(":grip$") then frame:Hide() end end
        end
    end)
end
function app:Apply()
    self:Safe("disposition", function()
        if self.SyncBagTools then self:SyncBagTools() end
        if self.LayoutSessionMarker then self:LayoutSessionMarker() end
        if self.InitMicroTooltip then self:InitMicroTooltip() end
        if not self.db.enabled then self:RestoreAll(); if self.LayoutOptions then self:LayoutOptions() end; return end
        local b,reason = self:Bridge()
        if not b then self:RestoreAll(); self.lastIssue=reason; return end
        self:ApplyViewport(b)
        self:PaintWorkspace(b)
        if self.ApplyNativeDialogs then self:ApplyNativeDialogs() end
        -- Resizing can temporarily restore the native HUD. Once the canvas is
        -- valid again, resume our existing copy without resetting its settings.
        if self.db.hud and self.ResumeNativeHUD and self:GetHUDState().mode=="blizzard" then self:ResumeNativeHUD() end
        self:ApplyHUD()
        if self.ApplyPanels then self:ApplyPanels() end
        if self.LayoutOptions then self:LayoutOptions() end
        if self.UpdateMinimapStatus then self:UpdateMinimapStatus() end
        if not self.verifyQueued then
            self.verifyQueued=true
            C_Timer.After(0.1,function()
                self.verifyQueued=false; self:CheckViewport()
                if self.options then self.options.status:SetText(self:StatusText()) end
            end)
        end
    end)
end
function app:ViewportDiagnostic()
    local blocked=self.db.lastBlockedAction
    if blocked then self:Message("Dernier blocage ("..blocked.time..") : "..blocked.event.." | version "..tostring(blocked.version or "antérieure/inconnue").." | "..blocked.action.." | "..tostring(blocked.operation or "appel natif")) end
    local pw,ph=GetPhysicalScreenSize()
    self:Message("Mesure native : "..pw.." × "..ph.." | Activation : "..tostring(self.db.enabled))
    self:Message("Interface : "..math.floor(UIParent:GetWidth()+0.5).." × "..math.floor(UIParent:GetHeight()+0.5).." unités | Échelle : "..UIParent:GetEffectiveScale())
    local b,reason=self:Bridge()
    if not b then self:Message(reason); return end
    self:Message("Jeu : "..b.game.w.." × "..b.game.h.." | Secondaire : "..b.workspace.w.." × "..b.workspace.h)
    self:Message("Canevas transmis : "..b.canvas.w.." × "..b.canvas.h)
    self:Message("Surface validée : "..tostring(self.surfaceState).." | Ancrage : "..tostring(self.viewportMethod))
    self:Message("Vue 3D mesurée : "..math.floor(WorldFrame:GetWidth()+0.5).." × "..math.floor(WorldFrame:GetHeight()+0.5).." unités | Cadrage vérifié : "..tostring(self.viewportActive))
    if self.lastIssue then self:Message(self.lastIssue) end
end
function app:SetEnabled(value)
    self.db.enabled=value; self.db.userDisabled=not value
    if value and self.ResumeNativeHUD then self:Safe("réactiver le HUD",function() self:ResumeNativeHUD() end) end
    self:Apply()
end
local events=CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:RegisterEvent("DISPLAY_SIZE_CHANGED")
events:RegisterEvent("UI_SCALE_CHANGED")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("CINEMATIC_STOP")
events:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
events:SetScript("OnEvent",function(_,event,name)
    if event=="ADDON_LOADED" and name==addonName then
        ForeverAddonLocalDB=type(ForeverAddonLocalDB)=="table" and ForeverAddonLocalDB or (type(ForeverDualScreenLocalDB)=="table" and ForeverDualScreenLocalDB or {})
        app.db=ForeverAddonLocalDB
        local defaults={enabled=true,hud=true,autoFit=true,minimapHidden=false,panels={WorldMapFrame=true,CharacterFrame=true,ContainerFrameCombinedBags=true,ChatFrame1=false},positions={},scales={},color={0,0,0},background="stone",profiles={},modules={bagTrash=false,bagMulti=false}}
        for k,v in pairs(defaults) do if app.db[k]==nil then app.db[k]=v end end
        if not app.db.simpleCompanionVersion then
            -- The calibration controls are retired. A stale manual rectangle
            -- must no longer override what the companion sends on reload.
            app.db.manualBridge=nil; app.db.simpleCompanionVersion=1
        end
        if not app.db.viewportSetupVersion then
            app.db.enabled=not app.db.userDisabled
            local c=app.db.color
            if c[1]==0.035 and c[2]==0.055 and c[3]==0.075 then app.db.color={0,0,0} end
            app.db.viewportSetupVersion=1
        end
    elseif event=="PLAYER_LOGIN" then
        app:CreateMinimapButton(); app:DiscoverPanels(); app:Apply()
        C_Timer.After(1,function() app:Apply(); C_Timer.After(0.1,function() app:CheckViewport() end) end)
        app:Message("Version "..app.version..". Clique sur l’icône de la minicarte pour les réglages, ou utilise /fds.")
    elseif event=="EDIT_MODE_LAYOUTS_UPDATED" and app.db then
        if not app.editModeRefreshQueued then
            app.editModeRefreshQueued=true
            C_Timer.After(0,function() app.editModeRefreshQueued=false; app:Apply() end)
        end
    elseif event=="PLAYER_REGEN_ENABLED" then
        local pending=app.pending; app.pending={}
        -- Restore first, then apply the latest requested state. No polling during combat.
        if pending.restaurer then app:Safe("restaurer",pending.restaurer) end
        for k,action in pairs(pending) do if k~="restaurer" then app:Safe(k,action) end end
    elseif app.db then
        if not app.minimapButton then app:CreateMinimapButton() end
        if event=="ADDON_LOADED" then app:DiscoverPanels() end
        if event~="ADDON_LOADED" or app.db.enabled then app:Apply() end
    end
end)
SLASH_FOREVERADDONLOCAL1="/fds"
SLASH_FOREVERADDONLOCAL2="/foreveraddon"
SLASH_FOREVERADDONLOCAL3="/fa"
SLASH_FOREVERADDONLOCAL4="/foreverdualscreen"
SlashCmdList.FOREVERADDONLOCAL=function(text)
    if text=="off" then app:SetEnabled(false); app:Message("Disposition désactivée.")
    elseif text=="on" then app:SetEnabled(true); app:Message("Activation demandee.")
    elseif text=="reset" then app.db.positions={}; app.db.scales={}; app:Apply()
    elseif text=="diag" then app:ViewportDiagnostic()
    elseif text=="hud" or text=="guide" or text=="wizard" then app:ShowHUDAssistant()
    else app:ShowOptions() end
end
