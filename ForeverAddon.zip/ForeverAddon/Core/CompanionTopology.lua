-- Donnees d'ecrans remplacees par le compagnon valide. Recharger l'interface apres extension.
ForeverAddonCompanionTopology = nil
