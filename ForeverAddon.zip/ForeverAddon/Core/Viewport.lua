local _,app=...
local function setMask(texture,x,y,w,h)
    if w<=0.01 or h<=0.01 then texture:Hide(); return end
    texture:ClearAllPoints(); texture:SetPoint("TOPLEFT",UIParent,"TOPLEFT",x,y)
    texture:SetSize(w,h); texture:Show()
end
local function uiFactor()
    local scale=WorldFrame:GetEffectiveScale()
    assert(type(scale)=="number" and scale>0,"Échelle de rendu invalide.")
    return UIParent:GetEffectiveScale()/scale
end
local function placeRectangle(x,y,w,h)
    local factor=uiFactor()
    local cx,cy=(x+w/2)*factor,(y-h/2)*factor
    WorldFrame:ClearAllPoints()
    local ok=pcall(WorldFrame.SetPoint,WorldFrame,"CENTER",UIParent,"TOPLEFT",cx,cy)
    if not ok then
        WorldFrame:ClearAllPoints()
        WorldFrame:SetPoint("CENTER",nil,"TOPLEFT",cx,cy)
        app.viewportMethod="SCREEN"
    else app.viewportMethod="INTERFACE" end
    WorldFrame:SetSize(w*factor,h*factor)
    return factor
end
function app:RestoreViewport()
    if not self.worldSnapshot then return end
    local saved=self.worldSnapshot
    if math.abs(UIParent:GetWidth()/UIParent:GetHeight()-saved.aspect)>0.003 then
        placeRectangle(0,0,UIParent:GetWidth(),UIParent:GetHeight())
    else
        WorldFrame:ClearAllPoints(); WorldFrame:SetSize(saved.width,saved.height)
        for _,p in ipairs(saved.points) do WorldFrame:SetPoint(unpack(p,1,5)) end
    end
    self.viewportActive=false
    if self.backdrop then self.backdrop:Hide() end
end
function app:ApplyViewport(b)
    if not self.worldSnapshot then
        local saved={width=WorldFrame:GetWidth(),height=WorldFrame:GetHeight(),aspect=UIParent:GetWidth()/UIParent:GetHeight(),points={}}
        for i=1,WorldFrame:GetNumPoints() do
            local a,r,rp,x,y=WorldFrame:GetPoint(i)
            saved.points[i]={a,r,rp,x,y}
        end
        self.worldSnapshot=saved
    end
    local x,y,w,h=self.Geometry.ToUI(b.game,b.canvas,UIParent:GetWidth(),UIParent:GetHeight())
    local ok,factor=pcall(placeRectangle,x,y,w,h)
    if not ok then
        self.viewportActive=false
        if self.backdrop then self.backdrop:Hide() end
        pcall(self.RestoreViewport,self)
        error("Cadrage refusé : "..tostring(factor))
    end
    self.expectedWorldWidth,self.expectedWorldHeight=w*factor,h*factor
    self.expectedWorldLeft=x*factor
    self.expectedWorldBottom=(UIParent:GetHeight()+y-h)*factor
    self.viewportActive=true; self.lastIssue=nil
end
function app:PaintWorkspace(b)
    if not self.backdrop then
        self.backdrop=CreateFrame("Frame",nil,UIParent)
        self.backdrop:SetAllPoints(UIParent); self.backdrop:SetFrameStrata("BACKGROUND")
        self.backdrop:SetFrameLevel(1); self.backdrop:EnableMouse(false)
        self.masks={}
        for i=1,4 do self.masks[i]=self.backdrop:CreateTexture(nil,"BACKGROUND") end
    end
    local width,height=UIParent:GetWidth(),UIParent:GetHeight()
    local x,y,w,h=self.Geometry.ToUI(b.game,b.canvas,width,height)
    local c=self.db.color
    for _,t in ipairs(self.masks) do t:SetColorTexture(c[1],c[2],c[3],1) end
    setMask(self.masks[1],0,0,x,height)
    setMask(self.masks[2],x+w,0,width-x-w,height)
    setMask(self.masks[3],x,0,w,-y)
    setMask(self.masks[4],x,y-h,w,height+y-h)
    if not self.workspaceTexture then self.workspaceTexture=self.backdrop:CreateTexture(nil,"ARTWORK") end
    if self.db.background=="stone" then
        local wx,wy,ww,wh=self.Geometry.ToUI(b.workspace,b.canvas,width,height)
        self.workspaceTexture:SetTexture("Interface\\AddOns\\ForeverAddon\\Media\\WorkspaceStone.tga")
        -- Exclude the captured image border; keep the stone, without its gray bottom rail.
        self.workspaceTexture:SetTexCoord(2/562,558/562,2/426,402/426)
        setMask(self.workspaceTexture,wx,wy,ww,wh)
    else self.workspaceTexture:Hide() end
    self.backdrop:Show()
end
function app:CheckViewport()
    if not self.db.enabled or not self.viewportActive then return end
    if InCombatLockdown() then self.pending["vérifier le cadrage"]=function() self:CheckViewport() end; return end
    local w,h=WorldFrame:GetWidth(),WorldFrame:GetHeight()
    if type(w)~="number" or type(h)~="number" then return end
    local matches=math.abs(w-self.expectedWorldWidth)<=2 and math.abs(h-self.expectedWorldHeight)<=2
    if WorldFrame.GetRect then
        local x,y=WorldFrame:GetRect()
        if type(x)=="number" and type(y)=="number" then
            matches=matches and math.abs(x-self.expectedWorldLeft)<=2 and math.abs(y-self.expectedWorldBottom)<=2
        end
    end
    if not matches then
        self.viewportActive=false
        if self.UpdateMinimapStatus then self:UpdateMinimapStatus() end
        self.lastIssue="La vue 3D ne correspond pas à l’écran choisi. Clique sur Réappliquer et consulte le diagnostic."
        if self.backdrop then self.backdrop:Hide() end
        self:Record(self.lastIssue); self:Message(self.lastIssue)
    end
end
