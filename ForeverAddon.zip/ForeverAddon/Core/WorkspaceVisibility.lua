local _,app=...
app.workspaceWanted={}; app.workspaceHidden={}; app.workspaceWatchers={}; app.workspaceCloseHooks={}
local function dead() return UnitIsDeadOrGhost and UnitIsDeadOrGhost("player") or false end
function app:KeepsWorkspacePanel(name)
    if not self.db or not self.db.enabled or not self.viewportActive or self.workspaceSuspended then return false end
    if name=="WorldMapFrame" then
        local f=_G[name]
        return self.db.panels.WorldMapFrame and not (f and f.IsMaximized and f:IsMaximized())
    end
    if name=="ContainerFrameCombinedBags" then return self.db.panels.ContainerFrameCombinedBags end
    if name:match("^ContainerFrame%d+$") and self.db.panels.ContainerFrameCombinedBags then
        local f=_G[name]; local id=f and f.GetID and f:GetID()
        if type(id)~="number" and self.workspaceWanted[name] then id=self.workspaceWanted[name].id end
        return type(id)=="number" and id>=0 and id<=(NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4)
    end
    return false
end
local function otherWindows()
    local function other(f)
        return f and f.IsShown and f:IsShown() and f~=GameMenuFrame and not app:KeepsWorkspacePanel(f.GetName and f:GetName() or "")
    end
    if GetUIPanel then
        for _,slot in ipairs({"left","center","right","doublewide","fullscreen"}) do if other(GetUIPanel(slot)) then return true end end
    end
    for _,name in pairs(UISpecialFrames or {}) do if other(_G[name]) then return true end end
    if other(EditModeManagerFrame) then return true end
    return false
end
function app:QueueWorkspaceVisibility()
    if self.workspaceFlushQueued then return end
    self.workspaceFlushQueued=true
    C_Timer.After(0,function()
        app.workspaceFlushQueued=false
        app:RestoreWorkspaceVisibility()
    end)
end
function app:BeginWorkspaceContext(reason)
    if not self.workspaceContext then
        self.workspaceContext={reason=reason,other=otherWindows(),menuWasShown=GameMenuFrame and GameMenuFrame:IsShown()}
    elseif reason=="death" then self.workspaceContext.reason="death"
    elseif GameMenuFrame and GameMenuFrame:IsShown() and reason=="escape" then self.workspaceContext.cancelMenu=true end
    self:QueueWorkspaceVisibility()
    return false -- observer only: do not consume Blizzard's Escape dispatcher
end
function app:RememberWorkspaceVisible(name,f)
    if not self:KeepsWorkspacePanel(name) then self.workspaceWanted[name]=nil; return end
    self.workspaceWanted[name]={id=f.GetID and f:GetID()}
    self.workspaceHidden[name]=nil
end
function app:WorkspacePanelHidden(name,f)
    if self.workspaceRestoring or f:IsShown() then return end -- parent hidden, not a real closure
    if not self:KeepsWorkspacePanel(name) or not self.workspaceWanted[name] then self.workspaceWanted[name]=nil; return end
    if self.workspaceManualBagClose and name:match("^ContainerFrame") then self.workspaceWanted[name]=nil; return end
    local stack=debugstack and debugstack(2,20,0) or ""
    -- Explicit map/bag toggles keep their normal meaning, even while dead.
    if stack:find("ToggleWorldMap",1,true) or stack:find("ToggleAllBags",1,true) or stack:find("ToggleBackpack",1,true) or stack:find("ToggleBag",1,true) then
        self.workspaceWanted[name]=nil; return
    end
    local batch=stack:find("CloseAllWindows",1,true)
    local menu=stack:find("ToggleGameMenu",1,true) or stack:find("GameMenuFrame_Show",1,true) or stack:find("TOGGLEGAMEMENU",1,true)
    if dead() and not self.workspaceWasDead then self:BeginWorkspaceContext("death")
    elseif menu then self:BeginWorkspaceContext("menu")
    elseif batch and not self.workspaceContext then self:BeginWorkspaceContext(stack:find("WithExceptions",1,true) and "death" or "batch") end
    local context=self.workspaceContext
    if context then
        context.other=context.other or otherWindows(); context.closed=true
        self.workspaceHidden[name]=true; self:QueueWorkspaceVisibility()
    else
        -- Showing the game menu can hide its former left panel before OnShow.
        -- Keep an undecided closure only until the end of this native action.
        local wanted=self.workspaceWanted[name]
        self.workspaceCandidateOther=self.workspaceCandidateOther or otherWindows()
        self.workspaceCandidates=self.workspaceCandidates or {}; self.workspaceCandidates[name]=wanted
        C_Timer.After(0,function()
            if app.workspaceCandidates and app.workspaceCandidates[name]==wanted then
                app.workspaceCandidates[name]=nil
                if not app.workspaceHidden[name] then app.workspaceWanted[name]=nil end
                if not next(app.workspaceCandidates) then app.workspaceCandidateOther=nil end
            end
        end)
    end
end
function app:AdoptWorkspaceCandidates()
    if self.workspaceContext then self.workspaceContext.other=self.workspaceContext.other or self.workspaceCandidateOther end
    for name,wanted in pairs(self.workspaceCandidates or {}) do
        if self:KeepsWorkspacePanel(name) then self.workspaceWanted[name]=wanted; self.workspaceHidden[name]=true; self.workspaceContext.closed=true end
    end
    self.workspaceCandidates={}; self.workspaceCandidateOther=nil
end
function app:RestoreWorkspaceVisibility()
    if InCombatLockdown() then self.pending["fenêtres secondaires"]=function() self:RestoreWorkspaceVisibility() end; return end
    local context=self.workspaceContext; self.workspaceContext=nil
    local hidden=self.workspaceHidden; self.workspaceHidden={}
    self.workspaceRestoring=true
    for name in pairs(hidden) do
        local wanted=self.workspaceWanted[name]; local f=_G[name]
        if wanted and f and not f:IsShown() and self:KeepsWorkspacePanel(name) then
            local ok,err=pcall(function()
                if name=="WorldMapFrame" then
                    -- Direct show avoids pushing the native game menu out of its slot.
                    f:Show()
                elseif name=="ContainerFrameCombinedBags" and OpenBackpack then OpenBackpack()
                elseif OpenBag and type(wanted.id)=="number" then OpenBag(wanted.id)
                else f:Show() end
                if f:IsShown() then app:PlacePanel(name) end
            end)
            if not ok then self:Record("Réouverture "..name.." : "..tostring(err)) end
        end
    end
    self.workspaceRestoring=false
    if context and context.closed and not context.other and not context.menuWasShown and not context.cancelMenu
        and (context.reason=="escape" or context.reason=="menu") and self.db.enabled and self.viewportActive then
        if GameMenuFrame and not GameMenuFrame:IsShown() then
            local ok,err=pcall(function()
                if GameMenuFrame_Show then GameMenuFrame_Show()
                elseif ShowUIPanel then ShowUIPanel(GameMenuFrame) else GameMenuFrame:Show() end
            end)
            if not ok then self:Record("Ouverture du menu : "..tostring(err)) end
        end
    end
end
function app:WatchWorkspacePanel(name,f)
    if name~="WorldMapFrame" and name~="ContainerFrameCombinedBags" and not name:match("^ContainerFrame%d+$") then return end
    if not self.workspaceWatchers[f] then
        self.workspaceWatchers[f]=true
        f:HookScript("OnShow",function() app:RememberWorkspaceVisible(name,f) end)
        f:HookScript("OnHide",function() app:WorkspacePanelHidden(name,f) end)
        if f:IsShown() then self:RememberWorkspaceVisible(name,f) end
    end
    local function closeButton(button)
        if not button or self.workspaceCloseHooks[button] then return end
        self.workspaceCloseHooks[button]=true
        button:HookScript("PreClick",function()
            if name=="WorldMapFrame" then
                app.workspaceWanted[name]=nil; app.workspaceHidden[name]=nil
                if app.workspaceCandidates then app.workspaceCandidates[name]=nil end
            else
                app.workspaceManualBagClose=true
                app.workspaceWanted[name]=nil; app.workspaceHidden[name]=nil
                C_Timer.After(0,function() app.workspaceManualBagClose=false end)
            end
        end)
    end
    closeButton(f.CloseButton); closeButton(f.closeButton); closeButton(f.BorderFrame and f.BorderFrame.CloseButton)
end
function app:InitWorkspaceVisibility()
    if not self.workspaceVisibilityEvents then
        self.workspaceWasDead=dead()
        local e=CreateFrame("Frame"); self.workspaceVisibilityEvents=e
        for _,event in ipairs({"PLAYER_DEAD","PLAYER_ALIVE","PLAYER_UNGHOST","PLAYER_LEAVING_WORLD","PLAYER_LOGOUT","PLAYER_ENTERING_WORLD"}) do e:RegisterEvent(event) end
        e:SetScript("OnEvent",function(_,event)
            if event=="PLAYER_LEAVING_WORLD" or event=="PLAYER_LOGOUT" then
                app.workspaceSuspended=true; app.workspaceContext=nil; app.workspaceHidden={}; app.workspaceWanted={}; return
            elseif event=="PLAYER_ENTERING_WORLD" then
                app.workspaceSuspended=false
                for f in pairs(app.workspaceWatchers) do if f:IsShown() then app:RememberWorkspaceVisible(f:GetName(),f) end end
                return
            end
            app.workspaceWasDead=dead()
            if event=="PLAYER_DEAD" then app:BeginWorkspaceContext("death")
            else
                for name in pairs(app.workspaceWanted) do if app:KeepsWorkspacePanel(name) then app.workspaceHidden[name]=true end end
                app:QueueWorkspaceVisibility()
            end
        end)
    end
    -- Do not register in Blizzard's ESC priority chain. The client owns spell
    -- cancellation/targeting and must finish them in its original secure path.
    -- Native OnHide/OnShow plus the post-hook below observe completed UI work.
    if GameMenuFrame and not self.workspaceMenuHooked then
        self.workspaceMenuHooked=true
        GameMenuFrame:HookScript("OnShow",function()
            app:BeginWorkspaceContext("menu")
            app:AdoptWorkspaceCandidates(); app:QueueWorkspaceVisibility()
        end)
        GameMenuFrame:HookScript("OnHide",function() if app.workspaceContext then app.workspaceContext.cancelMenu=true end end)
    end
    for _,name in ipairs({"MainMenuMicroButton","HelpMicroButton"}) do
        local b=_G[name]
        if b and not self.workspaceCloseHooks[b] then
            self.workspaceCloseHooks[b]=true; b:HookScript("PreClick",function() app:BeginWorkspaceContext("menu") end)
        end
    end
    -- Observe only AFTER the native Escape dispatcher has completed. Never
    -- invoke ToggleGameMenu from this hook or replay the native binding.
    if not self.workspaceToggleHooked and hooksecurefunc and type(ToggleGameMenu)=="function" then
        self.workspaceToggleHooked=true
        hooksecurefunc("ToggleGameMenu",function()
            if next(app.workspaceHidden) or next(app.workspaceCandidates or {}) then app:BeginWorkspaceContext("menu"); app:AdoptWorkspaceCandidates() end
        end)
    end
end
