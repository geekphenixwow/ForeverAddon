local _,app=...
local function finite(n) return type(n)=="number" and n==n and math.abs(n)<100000 end
function app:DecodeCompanion(raw)
    if type(raw)~="table" or raw.schema~=1 or not finite(raw.physicalWidth) or not finite(raw.physicalHeight)
        or raw.physicalWidth<=0 or raw.physicalHeight<=0 then return nil,"Configuration du compagnon absente ou invalide." end
    local function rect(source)
        if type(source)~="table" then return nil end
        for _,key in ipairs({"x","y","width","height"}) do if not finite(source[key]) then return nil end end
        return {x=source.x,y=raw.physicalHeight-source.y-source.height,w=source.width,h=source.height}
    end
    local data={protocol=1,active=true,companion=tostring(raw.companionVersion or "0.6"),
        canvas={x=0,y=0,w=raw.physicalWidth,h=raw.physicalHeight},game=rect(raw.game),workspace=rect(raw.workspace)}
    local valid,reason=self.Geometry.Validate(data)
    if not valid then return nil,reason end
    return data
end
function app:CompanionData()
    local raw=_G.ForeverAddonCompanionTopology
    if raw==nil then return nil end
    if raw==self.companionInput then return self.companionDecoded,self.companionError end
    self.companionInput=raw
    self.companionDecoded,self.companionError=self:DecodeCompanion(raw)
    return self.companionDecoded,self.companionError
end
