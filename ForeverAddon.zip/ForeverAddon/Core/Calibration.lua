local _,app=...
local function text(parent,value,x,y,width)
    local t=parent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    t:SetPoint("TOPLEFT",x,y); t:SetWidth(width or 700); t:SetJustifyH("LEFT"); t:SetText(value); return t
end
local function command(parent,value,x,y,w,action)
    local b=CreateFrame("Button",nil,parent,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",x,y); b:SetSize(w,30); b:SetText(value); b:SetScript("OnClick",action); return b
end
function app:ShowCalibration()
    if self.calibration then self.calibration:Show(); return end
    local f=CreateFrame("Frame","FDSLocalCalibration",UIParent,"BackdropTemplate")
    f:SetSize(780,460); f:SetPoint("CENTER"); f:SetFrameStrata("FULLSCREEN_DIALOG")
    f:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8",edgeFile="Interface\\Buttons\\WHITE8X8",edgeSize=1})
    f:SetBackdropColor(0.025,0.035,0.05,1); f:SetBackdropBorderColor(0.1,0.6,0.8,1)
    text(f,"Configurer la vue du jeu et l’écran secondaire",24,-24):SetFontObject("GameFontNormalLarge")
    text(f,"Indique les résolutions de tes deux écrans. Le jeu sera recadré sans couper l’image.\nCe réglage sert aussi si la configuration du compagnon n’a pas été chargée.",24,-60,730)
    local cw,ch=GetPhysicalScreenSize()
    local active=self:Bridge()
    local gw=active and active.game.w or math.floor(cw*4/7+0.5)
    local gh=active and active.game.h or ch
    local sw=active and active.workspace.w or cw-gw
    local sh=active and active.workspace.h or math.min(ch,math.floor(sw*9/16+0.5))
    local initialSide="right"
    if not active then
        local visibleAspect=UIParent:GetWidth()/UIParent:GetHeight()
        if visibleAspect>cw/ch*1.02 then
            gw,gh=cw,ch; sw=math.floor(ch*visibleAspect+0.5)-cw; sh=math.min(ch,math.floor(sw*9/16+0.5))
        elseif visibleAspect<cw/ch*0.98 then
            gw,gh=cw,ch; sh=math.floor(cw/visibleAspect+0.5)-ch; sw=math.min(cw,math.floor(sh*16/9+0.5)); initialSide="bottom"
        end
    end
    local fields={}
    local specs={{"Largeur du jeu",gw},{"Hauteur du jeu",gh},{"Largeur écran secondaire",sw},{"Hauteur écran secondaire",sh}}
    for i,s in ipairs(specs) do
        local col=(i-1)%2; local row=math.floor((i-1)/2)
        text(f,s[1],24+col*370,-120-row*64,330)
        local edit=CreateFrame("EditBox",nil,f,"InputBoxTemplate")
        edit:SetPoint("TOPLEFT",30+col*370,-144-row*64); edit:SetSize(330,28)
        edit:SetAutoFocus(false); edit:SetMaxLetters(5); edit:SetText(tostring(s[2])); fields[i]=edit
    end
    local side=initialSide
    local chosen=text(f,side=="bottom" and "Position du jeu : en bas" or "Position du jeu : à droite",24,-256,730)
    for i,s in ipairs({{"À gauche","left"},{"À droite","right"},{"En haut","top"},{"En bas","bottom"}}) do
        local key,title=s[2],s[1]
        command(f,title,24+(i-1)*184,-284,174,function() side=key; chosen:SetText("Position du jeu : "..title) end)
    end
    local align=CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    align:SetPoint("TOPLEFT",24,-328); align:SetSize(28,28); align:SetChecked(true)
    local caption=align:CreateFontString(nil,"OVERLAY","GameFontHighlight")
    caption:SetPoint("LEFT",align,"RIGHT",5,0); caption:SetText("Aligner les écrans en bas (ou à droite s’ils sont superposés)")
    local errorText=text(f,"",24,-366,730)
    command(f,"Appliquer les deux zones",24,-410,350,function()
        local width,height=GetPhysicalScreenSize()
        local b,reason=app.Geometry.CalibrationDraft(tonumber(fields[1]:GetText()),tonumber(fields[2]:GetText()),tonumber(fields[3]:GetText()),tonumber(fields[4]:GetText()),side,align:GetChecked())
        if not b then errorText:SetText(reason); return end
        local ready,state=app.Geometry.SurfaceState(b,width,height,UIParent:GetWidth(),UIParent:GetHeight())
        if not ready then errorText:SetText(state); return end
        app.db.manualBridge=b; app:SetEnabled(true); f:Hide()
        C_Timer.After(0.1,function() app:CheckViewport() end)
        if app.options then app.options.status:SetText(app:StatusText()) end
    end)
    command(f,"Annuler",400,-410,350,function() f:Hide() end)
    table.insert(UISpecialFrames,"FDSLocalCalibration"); self.calibration=f
end
